package com.hrmoja.dto;

import com.hrmoja.entity.PayrollJob.JobStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO for Payroll Job Status
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PayrollJobStatusDto {
    
    private Long jobId;
    private Long payrollPeriodId;
    private JobStatus status;
    private Integer totalEmployees;
    private Integer processedEmployees;
    private Integer failedEmployees;
    private Integer progressPercentage;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private String errorMessage;
    private Long durationSeconds;
    private String statusMessage;
    
    /**
     * Get human-readable status message
     */
    public String getStatusMessage() {
        if (statusMessage != null) {
            return statusMessage;
        }
        
        switch (status) {
            case QUEUED:
                return "Job queued, waiting to start...";
            case PROCESSING:
                return String.format("Processing %d of %d employees...", 
                    processedEmployees, totalEmployees);
            case COMPLETED:
                if (failedEmployees > 0) {
                    return String.format("Completed with %d failures out of %d employees", 
                        failedEmployees, totalEmployees);
                }
                return String.format("Successfully processed %d employees", totalEmployees);
            case FAILED:
                return "Job failed: " + (errorMessage != null ? errorMessage : "Unknown error");
            case CANCELLED:
                return "Job was cancelled";
            default:
                return "Unknown status";
        }
    }
    
    /**
     * Check if job is still running
     */
    public boolean isRunning() {
        return status == JobStatus.QUEUED || status == JobStatus.PROCESSING;
    }
    
    /**
     * Check if job is finished (completed, failed, or cancelled)
     */
    public boolean isFinished() {
        return status == JobStatus.COMPLETED || 
               status == JobStatus.FAILED || 
               status == JobStatus.CANCELLED;
    }
}
