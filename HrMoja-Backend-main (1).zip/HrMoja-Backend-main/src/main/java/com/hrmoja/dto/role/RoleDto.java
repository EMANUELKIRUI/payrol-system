package com.hrmoja.dto.role;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Role DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleDto {

    private Long id;
    private String name;
    private String code;
    private String description;
    private Integer level;
    private boolean isSystemRole;
    private boolean isActive;
    private List<String> permissions;
    private List<Long> permissionIds;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
