package com.hrmoja.dto.organization;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Organization Registration Request DTO
 * Used for onboarding new organizations to the SaaS platform
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrganizationRegistrationRequest {

    // Organization Details
    @NotBlank(message = "Organization name is required")
    @Size(max = 255)
    private String organizationName;

    private String legalName;

    private String registrationNumber;

    @NotBlank(message = "Tax identification number is required")
    private String taxIdentificationNumber;

    @NotNull(message = "Country is required")
    private Long countryId;

    @NotBlank(message = "Address is required")
    private String addressLine1;

    private String addressLine2;

    @NotBlank(message = "City is required")
    private String city;

    private String stateProvince;

    private String postalCode;

    @NotBlank(message = "Phone number is required")
    private String phoneNumber;

    @NotBlank(message = "Organization email is required")
    @Email(message = "Organization email must be valid")
    private String organizationEmail;

    private String website;

    // Super Admin User Details
    @NotBlank(message = "Admin first name is required")
    private String adminFirstName;

    @NotBlank(message = "Admin last name is required")
    private String adminLastName;

    @NotBlank(message = "Admin email is required")
    @Email(message = "Admin email must be valid")
    private String adminEmail;

    @NotBlank(message = "Admin username is required")
    @Size(min = 3, max = 100)
    private String adminUsername;

    @NotBlank(message = "Admin password is required")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String adminPassword;

    private String adminPhoneNumber;

    // Headquarters Branch Details
    @NotBlank(message = "Branch name is required")
    private String branchName;

    private String branchCity;
}
