package com.hrmoja.dto.payroll;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollComponentDto {

    private Long id;

    @NotNull(message = "Organization is required")
    private Long organizationId;

    @NotNull(message = "Component type is required")
    private Long componentTypeId;
    
    private String componentTypeName;
    private String calculationCategory;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Code is required")
    private String code;

    private String description;

    @NotBlank(message = "Calculation method is required")
    private String calculationMethod;

    private String calculationBasis;
    private BigDecimal fixedAmount;
    private BigDecimal percentageValue;
    private BigDecimal maxAmount;
    private String formula;

    private boolean isTaxable;
    private boolean isPensionable;
    private boolean affectsGross;
    private boolean affectsNet;
    private boolean displayOnPayslip;
    private Integer priorityOrder;
    private boolean isStatutory;
    private boolean isActive;
    private String notes;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
