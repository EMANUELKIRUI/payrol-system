package com.hrmoja.dto.salary;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Employee Salary Structure DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeSalaryDto {

    private Long id;
    private Long employeeId;
    private LocalDate effectiveDate;
    private LocalDate endDate;
    private Double basicSalary;
    private String currencyCode;
    private Long payFrequencyId;
    private String payFrequencyName;
    private Long paymentMethodId;
    private boolean active;
    private Long approvedBy;
    private LocalDate approvedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
