package com.hrmoja.dto.role;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

/**
 * Role Creation Request DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleCreateRequest {

    @NotBlank(message = "Role name is required")
    @Size(max = 100)
    private String name;

    @NotBlank(message = "Role code is required")
    @Size(max = 100)
    private String code;

    private String description;
    private Integer level = 0;
    private Set<Long> permissionIds;
}
