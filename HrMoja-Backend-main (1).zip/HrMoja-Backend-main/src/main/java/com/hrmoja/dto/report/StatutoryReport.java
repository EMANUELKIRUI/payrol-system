package com.hrmoja.dto.report;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StatutoryReport {
    private String periodName;
    private LocalDate startDate;
    private LocalDate endDate;
    private String reportType; // PAYE, NSSF, LST
    
    private Integer totalEmployees;
    private BigDecimal totalGrossSalary;
    private BigDecimal totalTaxableIncome;
    
    // PAYE specific
    private BigDecimal totalPayeTax;
    
    // NSSF specific
    private BigDecimal totalNssfEmployee;
    private BigDecimal totalNssfEmployer;
    private BigDecimal totalNssfContribution;
    
    // LST specific
    private BigDecimal totalLst;
    
    private BigDecimal totalAmount;
}
