package com.hrmoja.dto.dashboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * Dashboard Metrics DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardMetricsDto {
    
    // Overview metrics
    private Long totalEmployees;
    private Long activeEmployees;
    private Long inactiveEmployees;
    private BigDecimal monthlyPayroll;
    private Integer pendingTasks;
    private Double teamPerformance;
    
    // Trend data
    private List<MonthlyTrendDto> payrollTrend;
    private List<MonthlyTrendDto> employeeTrend;
    
    // Department distribution
    private List<DepartmentStatsDto> departmentDistribution;
    
    // Recent activities
    private List<ActivityDto> recentActivities;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MonthlyTrendDto {
        private String month;
        private BigDecimal amount;
        private Long count;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DepartmentStatsDto {
        private String departmentName;
        private Long employeeCount;
        private BigDecimal totalSalary;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ActivityDto {
        private String type;
        private String description;
        private String timestamp;
        private String user;
    }
}
