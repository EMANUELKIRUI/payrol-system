package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeGradeDto {

    private Long id;

    @NotNull(message = "Organization is required")
    private Long organizationId;

    @NotBlank(message = "Name is required")
    private String name;

    private String code;

    @NotNull(message = "Level is required")
    private Integer level;

    private BigDecimal minSalary;
    private BigDecimal maxSalary;
    private String description;
    private boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
