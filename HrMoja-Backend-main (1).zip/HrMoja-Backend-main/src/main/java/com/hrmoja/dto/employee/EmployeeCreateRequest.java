package com.hrmoja.dto.employee;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Employee Creation Request DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeCreateRequest {

    @NotNull(message = "Organization is required")
    private Long organizationId;

    private Long branchId;
    private Long departmentId;

    // Personal Information
    @NotBlank(message = "First name is required")
    private String firstName;

    private String middleName;

    @NotBlank(message = "Last name is required")
    private String lastName;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    private LocalDate dateOfBirth;

    private String gender;
    private String maritalStatus;
    private String nationality;
    private String nationalId;
    private String passportNumber;

    // Contact Information
    @Email(message = "Personal email must be valid")
    private String personalEmail;

    @Email(message = "Work email must be valid")
    private String workEmail;

    @NotBlank(message = "Mobile phone is required")
    private String mobilePhone;

    private String homePhone;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private String emergencyContactRelationship;

    // Address
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String postalCode;
    private Long countryId;

    // Employment Information
    @NotNull(message = "Hire date is required")
    private LocalDate hireDate;

    private LocalDate probationEndDate;

    @NotNull(message = "Employment type is required")
    private Long employmentTypeId;

    @NotNull(message = "Job title is required")
    private Long jobTitleId;

    private Long employeeGradeId;
    private Long reportsToEmployeeId;

    // Salary Information
    private Double basicSalary;
    private String currencyCode;
    private Long payFrequencyId;

    // User Account Creation
    private Boolean createUserAccount;
    private Long roleId;

    // Bank Details
    private Long bankId;
    private Long bankBranchId;
    private String accountNumber;
    private String accountName;
    private String accountType;
    private String swiftCode;
    private String iban;
}
