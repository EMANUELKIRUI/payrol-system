package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "tax_reliefs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxRelief extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tax_configuration_id", nullable = false)
    private TaxConfiguration taxConfiguration;

    @Column(name = "relief_code", nullable = false, length = 50)
    private String reliefCode;

    @Column(name = "relief_name", nullable = false, length = 200)
    private String reliefName;

    @Column(name = "relief_type", nullable = false, length = 50)
    private String reliefType; // FIXED, PERCENTAGE, FORMULA

    @Column(name = "fixed_amount", precision = 15, scale = 2)
    private BigDecimal fixedAmount;

    @Column(name = "percentage_value", precision = 5, scale = 2)
    private BigDecimal percentageValue;

    @Column(name = "max_amount", precision = 15, scale = 2)
    private BigDecimal maxAmount;

    @Column(name = "calculation_basis", length = 50)
    private String calculationBasis; // GROSS, TAXABLE, CONTRIBUTION

    @Column(columnDefinition = "TEXT")
    private String formula;

    @Column(name = "is_mandatory")
    private boolean isMandatory = false;

    @Column(name = "applies_to", length = 50)
    private String appliesTo = "ALL"; // ALL, RESIDENT, NON_RESIDENT

    @Column(columnDefinition = "TEXT")
    private String description;
}
