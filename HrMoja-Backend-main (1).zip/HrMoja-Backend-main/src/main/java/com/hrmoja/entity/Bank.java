package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Bank Entity
 */
@Entity
@Table(name = "banks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bank extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id", nullable = false)
    private Country country;

    @Column(nullable = false)
    private String name;

    @Column(length = 50)
    private String code;

    @Column(name = "swift_code", length = 20)
    private String swiftCode;

    @Column(name = "is_active")
    private boolean isActive = true;
}
