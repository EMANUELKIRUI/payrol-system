package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * PayrollJob Entity - Tracks async payroll processing jobs
 */
@Entity
@Table(name = "payroll_jobs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollJob {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_period_id", nullable = false)
    private PayrollPeriod payrollPeriod;

    @Column(name = "payroll_period_id", insertable = false, updatable = false)
    private Long payrollPeriodId;

    @Column(name = "status", nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private JobStatus status;

    @Column(name = "total_employees")
    private Integer totalEmployees;

    @Column(name = "processed_employees")
    private Integer processedEmployees;

    @Column(name = "failed_employees")
    private Integer failedEmployees;

    @Column(name = "progress_percentage")
    private Integer progressPercentage;

    @Column(name = "started_at")
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    @Column(name = "started_by")
    private Long startedBy;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) {
            status = JobStatus.QUEUED;
        }
        if (processedEmployees == null) {
            processedEmployees = 0;
        }
        if (failedEmployees == null) {
            failedEmployees = 0;
        }
        if (progressPercentage == null) {
            progressPercentage = 0;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
        
        // Calculate progress percentage
        if (totalEmployees != null && totalEmployees > 0) {
            progressPercentage = (int) ((processedEmployees * 100.0) / totalEmployees);
        }
    }

    public enum JobStatus {
        QUEUED,
        PROCESSING,
        COMPLETED,
        FAILED,
        CANCELLED
    }
}
