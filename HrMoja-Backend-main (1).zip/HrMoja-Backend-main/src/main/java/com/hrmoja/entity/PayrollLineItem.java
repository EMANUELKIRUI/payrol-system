package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "payroll_line_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollLineItem extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_payroll_record_id", nullable = false)
    private EmployeePayrollRecord employeePayrollRecord;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "component_id")
    private PayrollComponent component;

    @Column(name = "component_name", nullable = false, length = 200)
    private String componentName;

    @Column(name = "component_code", nullable = false, length = 50)
    private String componentCode;

    @Column(name = "component_category", nullable = false, length = 50)
    private String componentCategory; // EARNING, DEDUCTION, TAX, STATUTORY, BENEFIT

    // Calculation Details
    @Column(name = "calculation_method", length = 30)
    private String calculationMethod; // FIXED, PERCENTAGE, FORMULA, RANGE

    @Column(name = "calculation_basis", length = 50)
    private String calculationBasis; // BASIC_SALARY, GROSS_SALARY, TAXABLE_INCOME

    @Column(name = "rate_or_amount", precision = 15, scale = 2)
    private BigDecimal rateOrAmount;

    @Column(precision = 10, scale = 2)
    private BigDecimal quantity = BigDecimal.ONE;

    // Amount
    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount = BigDecimal.ZERO;

    // Flags
    @Column(name = "is_taxable")
    private boolean isTaxable = true;

    @Column(name = "is_pensionable")
    private boolean isPensionable = true;

    @Column(name = "is_statutory")
    private boolean isStatutory = false;

    @Column(name = "display_order")
    private Integer displayOrder = 0;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
