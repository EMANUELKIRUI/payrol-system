package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "payroll_runs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollRun extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_period_id", nullable = false)
    private PayrollPeriod payrollPeriod;

    @Column(name = "run_number", nullable = false)
    private Integer runNumber;

    @Column(name = "run_type", nullable = false, length = 20)
    private String runType = "REGULAR"; // REGULAR, ADJUSTMENT, BONUS, OFF_CYCLE

    @Column(nullable = false, length = 20)
    private String status = "DRAFT"; // DRAFT, PROCESSING, COMPLETED, FAILED

    @Column(name = "total_employees_processed")
    private Integer totalEmployeesProcessed = 0;

    @Column(name = "total_employees_failed")
    private Integer totalEmployeesFailed = 0;

    @Column(name = "total_gross_pay", precision = 15, scale = 2)
    private BigDecimal totalGrossPay = BigDecimal.ZERO;

    @Column(name = "total_deductions", precision = 15, scale = 2)
    private BigDecimal totalDeductions = BigDecimal.ZERO;

    @Column(name = "total_net_pay", precision = 15, scale = 2)
    private BigDecimal totalNetPay = BigDecimal.ZERO;

    @Column(name = "processing_started_at")
    private LocalDateTime processingStartedAt;

    @Column(name = "processing_completed_at")
    private LocalDateTime processingCompletedAt;

    @Column(name = "error_log", columnDefinition = "TEXT")
    private String errorLog;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
