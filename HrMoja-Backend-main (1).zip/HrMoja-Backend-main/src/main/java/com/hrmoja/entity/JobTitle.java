package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Job Title Entity
 */
@Entity
@Table(name = "job_titles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobTitle extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id", nullable = false)
    private Organization organization;

    @Column(nullable = false)
    private String title;

    @Column(length = 50)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column
    private Integer level;

    @Column(name = "is_active")
    private boolean isActive = true;
}
