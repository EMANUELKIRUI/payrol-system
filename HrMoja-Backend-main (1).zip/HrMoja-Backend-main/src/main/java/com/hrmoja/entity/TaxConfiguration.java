package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "payroll_tax_configurations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxConfiguration extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id", nullable = false)
    private Organization organization;

    @Column(name = "country_code", nullable = false, length = 3)
    private String countryCode; // UG, KE, TZ, RW, etc.

    @Column(name = "tax_year", nullable = false)
    private Integer taxYear;

    @Column(name = "effective_from", nullable = false)
    private LocalDate effectiveFrom;

    @Column(name = "effective_to")
    private LocalDate effectiveTo;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(columnDefinition = "TEXT")
    private String description;

    // Note: Relationships to payroll_tax_brackets and payroll_tax_reliefs
    // can be added later when needed for processing
}
