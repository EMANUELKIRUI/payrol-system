package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Country Entity for multi-country support
 */
@Entity
@Table(name = "countries")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Country extends BaseEntity {

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 3)
    private String code;

    @Column(name = "iso_code", nullable = false, unique = true, length = 2)
    private String isoCode;

    @Column(name = "currency_code", nullable = false, length = 3)
    private String currencyCode;

    @Column(name = "currency_name", nullable = false, length = 50)
    private String currencyName;

    @Column(name = "currency_symbol", length = 10)
    private String currencySymbol;

    @Column(nullable = false, length = 50)
    private String timezone;

    @Column(name = "date_format", length = 20)
    private String dateFormat = "yyyy-MM-dd";

    @Column(name = "is_active")
    private boolean isActive = true;
}
