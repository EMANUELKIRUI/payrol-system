package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * Payroll Component Entity - Earnings, Deductions, Benefits, etc.
 */
@Entity
@Table(name = "payroll_components")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollComponent extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id", nullable = false)
    private Organization organization;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "component_type_id", nullable = false)
    private PayrollComponentType componentType;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(nullable = false, length = 50)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "calculation_method", nullable = false, length = 30)
    private String calculationMethod; // FIXED, PERCENTAGE, FORMULA, RANGE

    @Column(name = "calculation_basis", length = 30)
    private String calculationBasis; // BASIC_SALARY, GROSS_SALARY, TAXABLE_INCOME

    @Column(name = "fixed_amount", precision = 15, scale = 2)
    private BigDecimal fixedAmount;

    @Column(name = "percentage_value", precision = 5, scale = 2)
    private BigDecimal percentageValue;

    @Column(name = "max_amount", precision = 15, scale = 2)
    private BigDecimal maxAmount;

    @Column(columnDefinition = "TEXT")
    private String formula;

    @Column(name = "is_taxable")
    private boolean isTaxable = true;

    @Column(name = "is_pensionable")
    private boolean isPensionable = true;

    @Column(name = "affects_gross")
    private boolean affectsGross = true;

    @Column(name = "affects_net")
    private boolean affectsNet = true;

    @Column(name = "display_on_payslip")
    private boolean displayOnPayslip = true;

    @Column(name = "priority_order")
    private Integer priorityOrder = 0;

    @Column(name = "is_statutory")
    private boolean isStatutory = false;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
