package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.report.DepartmentPayrollReport;
import com.hrmoja.dto.report.PayrollSummaryReport;
import com.hrmoja.dto.report.StatutoryReport;
import com.hrmoja.service.ExcelReportService;
import com.hrmoja.service.PayrollReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Payroll Reports Controller
 */
@RestController
@RequestMapping("/api/payroll/reports")
@RequiredArgsConstructor
@Tag(name = "Payroll Reports", description = "Payroll reporting and analytics")
@SecurityRequirement(name = "bearerAuth")
public class PayrollReportController {

    private final PayrollReportService reportService;
    private final ExcelReportService excelService;

    @GetMapping("/periods/{periodId}/summary")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get payroll summary report")
    public ResponseEntity<ApiResponse<PayrollSummaryReport>> getPayrollSummary(@PathVariable Long periodId) {
        PayrollSummaryReport report = reportService.generatePayrollSummary(periodId);
        return ResponseEntity.ok(ApiResponse.success(report));
    }

    @GetMapping("/periods/{periodId}/departments")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get department-wise payroll report")
    public ResponseEntity<ApiResponse<List<DepartmentPayrollReport>>> getDepartmentReport(@PathVariable Long periodId) {
        List<DepartmentPayrollReport> report = reportService.generateDepartmentReport(periodId);
        return ResponseEntity.ok(ApiResponse.success(report));
    }

    @GetMapping("/periods/{periodId}/statutory/paye")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get PAYE statutory report")
    public ResponseEntity<ApiResponse<StatutoryReport>> getPayeReport(@PathVariable Long periodId) {
        StatutoryReport report = reportService.generatePayeReport(periodId);
        return ResponseEntity.ok(ApiResponse.success(report));
    }

    @GetMapping("/periods/{periodId}/statutory/nssf")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get NSSF statutory report")
    public ResponseEntity<ApiResponse<StatutoryReport>> getNssfReport(@PathVariable Long periodId) {
        StatutoryReport report = reportService.generateNssfReport(periodId);
        return ResponseEntity.ok(ApiResponse.success(report));
    }

    @GetMapping("/periods/{periodId}/statutory/lst")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get LST statutory report")
    public ResponseEntity<ApiResponse<StatutoryReport>> getLstReport(@PathVariable Long periodId) {
        StatutoryReport report = reportService.generateLstReport(periodId);
        return ResponseEntity.ok(ApiResponse.success(report));
    }

    @GetMapping("/periods/{periodId}/export/excel")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Export payroll report to Excel")
    public ResponseEntity<byte[]> exportToExcel(@PathVariable Long periodId) {
        byte[] excelBytes = excelService.generatePayrollExcelReport(periodId);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "payroll_report_" + periodId + ".xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelBytes);
    }
}
