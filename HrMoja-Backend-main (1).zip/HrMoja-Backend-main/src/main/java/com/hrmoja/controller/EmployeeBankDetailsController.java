package com.hrmoja.controller;

import com.hrmoja.dto.bank.EmployeeBankDetailsDto;
import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.service.EmployeeBankDetailsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Employee Bank Details Controller
 */
@RestController
@RequestMapping("/api/employees/{employeeId}/bank-details")
@RequiredArgsConstructor
@Tag(name = "Employee Bank Details", description = "Employee bank details management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class EmployeeBankDetailsController {

    private final EmployeeBankDetailsService bankDetailsService;

    @GetMapping("/primary")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee's primary bank details")
    public ResponseEntity<ApiResponse<EmployeeBankDetailsDto>> getPrimaryBankDetails(@PathVariable Long employeeId) {
        return ResponseEntity.ok(ApiResponse.success(bankDetailsService.getPrimaryBankDetails(employeeId)));
    }

    @GetMapping
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get all employee's bank details")
    public ResponseEntity<ApiResponse<List<EmployeeBankDetailsDto>>> getAllBankDetails(@PathVariable Long employeeId) {
        return ResponseEntity.ok(ApiResponse.success(bankDetailsService.getAllBankDetails(employeeId)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Create bank details for employee")
    public ResponseEntity<ApiResponse<EmployeeBankDetailsDto>> createBankDetails(
            @PathVariable Long employeeId,
            @Valid @RequestBody EmployeeBankDetailsDto dto) {
        dto.setEmployeeId(employeeId);
        return ResponseEntity.ok(ApiResponse.success("Bank details created successfully",
                bankDetailsService.createBankDetails(dto)));
    }

    @PutMapping("/{bankDetailsId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Update employee bank details")
    public ResponseEntity<ApiResponse<EmployeeBankDetailsDto>> updateBankDetails(
            @PathVariable Long employeeId,
            @PathVariable Long bankDetailsId,
            @Valid @RequestBody EmployeeBankDetailsDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Bank details updated successfully",
                bankDetailsService.updateBankDetails(employeeId, bankDetailsId, dto)));
    }

    @DeleteMapping("/{bankDetailsId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Deactivate employee bank details")
    public ResponseEntity<ApiResponse<Void>> deactivateBankDetails(
            @PathVariable Long employeeId,
            @PathVariable Long bankDetailsId) {
        bankDetailsService.deactivateBankDetails(employeeId, bankDetailsId);
        return ResponseEntity.ok(ApiResponse.success("Bank details deactivated successfully", null));
    }
}
