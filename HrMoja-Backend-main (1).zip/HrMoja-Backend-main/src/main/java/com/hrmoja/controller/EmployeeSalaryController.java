package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.salary.EmployeeSalaryDto;
import com.hrmoja.service.EmployeeSalaryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Employee Salary Controller
 */
@RestController
@RequestMapping("/api/employees/{employeeId}/salary")
@RequiredArgsConstructor
@Tag(name = "Employee Salary", description = "Employee salary structure management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class EmployeeSalaryController {

    private final EmployeeSalaryService salaryService;

    @GetMapping("/current")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee's current active salary")
    public ResponseEntity<ApiResponse<EmployeeSalaryDto>> getCurrentSalary(@PathVariable Long employeeId) {
        return ResponseEntity.ok(ApiResponse.success(salaryService.getCurrentSalary(employeeId)));
    }

    @GetMapping("/history")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee's salary history")
    public ResponseEntity<ApiResponse<List<EmployeeSalaryDto>>> getSalaryHistory(@PathVariable Long employeeId) {
        return ResponseEntity.ok(ApiResponse.success(salaryService.getSalaryHistory(employeeId)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Create new salary structure for employee")
    public ResponseEntity<ApiResponse<EmployeeSalaryDto>> createSalary(
            @PathVariable Long employeeId, 
            @Valid @RequestBody EmployeeSalaryDto dto) {
        dto.setEmployeeId(employeeId);
        return ResponseEntity.ok(ApiResponse.success("Salary structure created successfully", 
                salaryService.createSalary(dto)));
    }

    @PutMapping("/{salaryId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Update employee salary structure")
    public ResponseEntity<ApiResponse<EmployeeSalaryDto>> updateSalary(
            @PathVariable Long employeeId,
            @PathVariable Long salaryId,
            @Valid @RequestBody EmployeeSalaryDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Salary structure updated successfully",
                salaryService.updateSalary(employeeId, salaryId, dto)));
    }

    @DeleteMapping("/{salaryId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Deactivate employee salary structure")
    public ResponseEntity<ApiResponse<Void>> deactivateSalary(
            @PathVariable Long employeeId,
            @PathVariable Long salaryId) {
        salaryService.deactivateSalary(employeeId, salaryId);
        return ResponseEntity.ok(ApiResponse.success("Salary structure deactivated successfully", null));
    }
}
