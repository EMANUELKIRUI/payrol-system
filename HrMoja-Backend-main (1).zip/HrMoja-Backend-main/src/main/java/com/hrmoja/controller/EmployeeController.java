package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.employee.EmployeeCreateRequest;
import com.hrmoja.dto.employee.EmployeeDto;
import com.hrmoja.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
@Tag(name = "Employees", description = "Employee management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping
    @PreAuthorize("hasAuthority('EMPLOYEE_CREATE')")
    @Operation(summary = "Create new employee")
    public ResponseEntity<ApiResponse<EmployeeDto>> createEmployee(@Valid @RequestBody EmployeeCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Employee created successfully", employeeService.createEmployee(request)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee by ID")
    public ResponseEntity<ApiResponse<EmployeeDto>> getEmployeeById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(employeeService.getEmployeeById(id)));
    }

    @GetMapping("/number/{employeeNumber}")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee by employee number")
    public ResponseEntity<ApiResponse<EmployeeDto>> getEmployeeByNumber(@PathVariable String employeeNumber) {
        return ResponseEntity.ok(ApiResponse.success(employeeService.getEmployeeByNumber(employeeNumber)));
    }

    @GetMapping("/organization/{organizationId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get all employees by organization")
    public ResponseEntity<ApiResponse<List<EmployeeDto>>> getEmployeesByOrganization(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(employeeService.getEmployeesByOrganization(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/paginated")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employees paginated")
    public ResponseEntity<ApiResponse<Page<EmployeeDto>>> getEmployeesPaginated(
            @PathVariable Long organizationId, Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(employeeService.getEmployeesPaginated(organizationId, pageable)));
    }

    @GetMapping("/organization/{organizationId}/search")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Search employees with filters")
    public ResponseEntity<ApiResponse<Page<EmployeeDto>>> searchEmployees(
            @PathVariable Long organizationId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long departmentId,
            @RequestParam(required = false) Long branchId,
            @RequestParam(required = false) Long employmentTypeId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Boolean isActive,
            Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                employeeService.searchEmployeesWithFilters(organizationId, search, departmentId, 
                        branchId, employmentTypeId, status, isActive, pageable)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('EMPLOYEE_UPDATE')")
    @Operation(summary = "Update employee")
    public ResponseEntity<ApiResponse<EmployeeDto>> updateEmployee(@PathVariable Long id, @Valid @RequestBody EmployeeDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Employee updated successfully", employeeService.updateEmployee(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('EMPLOYEE_DELETE')")
    @Operation(summary = "Deactivate employee")
    public ResponseEntity<ApiResponse<Void>> deactivateEmployee(@PathVariable Long id, @RequestParam String reason) {
        employeeService.deactivateEmployee(id, reason);
        return ResponseEntity.ok(ApiResponse.success("Employee deactivated successfully", null));
    }

    @GetMapping("/organization/{organizationId}/count")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get employee count statistics for organization")
    public ResponseEntity<ApiResponse<java.util.Map<String, Long>>> getEmployeeCount(@PathVariable Long organizationId) {
        Long totalCount = employeeService.getEmployeeCount(organizationId);
        Long activeCount = employeeService.getActiveEmployeeCount(organizationId);
        
        java.util.Map<String, Long> stats = new java.util.HashMap<>();
        stats.put("total", totalCount);
        stats.put("active", activeCount);
        stats.put("inactive", totalCount - activeCount);
        
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
