package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.service.BankFileExportService;
import com.hrmoja.service.PayslipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Payslip and Bank File Export Controller
 */
@RestController
@RequestMapping("/api/payroll")
@RequiredArgsConstructor
@Tag(name = "Payslips & Bank Files", description = "Payslip generation and bank file exports")
@SecurityRequirement(name = "bearerAuth")
public class PayslipController {

    private final PayslipService payslipService;
    private final BankFileExportService bankFileService;

    @GetMapping("/records/{recordId}/payslip")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Generate PDF payslip for employee")
    public ResponseEntity<byte[]> generatePayslip(@PathVariable Long recordId) {
        byte[] pdfBytes = payslipService.generatePayslip(recordId);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "payslip_" + recordId + ".pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .body(pdfBytes);
    }

    @GetMapping("/periods/{periodId}/bank-file")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Generate bank file for salary disbursement")
    public ResponseEntity<byte[]> generateBankFile(
            @PathVariable Long periodId,
            @RequestParam(defaultValue = "CSV") String format) {

        byte[] fileBytes = bankFileService.generateBankFile(periodId, format);

        String filename = "bank_file_" + periodId + "." + format.toLowerCase();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", filename);

        return ResponseEntity.ok()
                .headers(headers)
                .body(fileBytes);
    }

    @GetMapping("/periods/{periodId}/bank-summary")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get bank upload summary")
    public ResponseEntity<ApiResponse<String>> getBankUploadSummary(@PathVariable Long periodId) {
        String summary = bankFileService.generateBankUploadSummary(periodId);
        return ResponseEntity.ok(ApiResponse.success(summary));
    }
}
