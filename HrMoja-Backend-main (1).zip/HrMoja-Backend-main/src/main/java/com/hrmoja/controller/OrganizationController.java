package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.settings.OrganizationDto;
import com.hrmoja.service.OrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/settings/organizations")
@RequiredArgsConstructor
@Tag(name = "Settings - Organizations", description = "Organization management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class OrganizationController {

    private final OrganizationService organizationService;

    @GetMapping
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get all organizations")
    public ResponseEntity<ApiResponse<List<OrganizationDto>>> getAllOrganizations() {
        return ResponseEntity.ok(ApiResponse.success(organizationService.getAllOrganizations()));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<OrganizationDto>>> getActiveOrganizations() {
        return ResponseEntity.ok(ApiResponse.success(organizationService.getActiveOrganizations()));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<OrganizationDto>> getOrganizationById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(organizationService.getOrganizationById(id)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<OrganizationDto>> createOrganization(@Valid @RequestBody OrganizationDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Organization created successfully", organizationService.createOrganization(dto)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<OrganizationDto>> updateOrganization(@PathVariable Long id, @Valid @RequestBody OrganizationDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Organization updated successfully", organizationService.updateOrganization(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<Void>> toggleOrganizationStatus(@PathVariable Long id) {
        organizationService.toggleOrganizationStatus(id);
        return ResponseEntity.ok(ApiResponse.success("Organization status updated successfully", null));
    }
}
