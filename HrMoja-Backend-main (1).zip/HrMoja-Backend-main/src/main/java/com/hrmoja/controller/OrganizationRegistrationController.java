package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.organization.OrganizationRegistrationRequest;
import com.hrmoja.dto.organization.OrganizationRegistrationResponse;
import com.hrmoja.service.OrganizationRegistrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Organization Registration Controller
 * Handles multi-tenant organization onboarding
 */
@RestController
@RequestMapping("/api/organization")
@RequiredArgsConstructor
@Tag(name = "Organization Registration", description = "Multi-tenant organization onboarding endpoints")
public class OrganizationRegistrationController {

    private final OrganizationRegistrationService registrationService;

    @PostMapping("/register")
    @Operation(
        summary = "Register new organization",
        description = "Register a new organization with super admin user. This is the main onboarding endpoint for the SaaS platform."
    )
    public ResponseEntity<ApiResponse<OrganizationRegistrationResponse>> registerOrganization(
            @Valid @RequestBody OrganizationRegistrationRequest request) {
        
        OrganizationRegistrationResponse response = registrationService.registerOrganization(request);
        
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Organization registered successfully", response));
    }

    @GetMapping("/check-username/{username}")
    @Operation(summary = "Check username availability", description = "Check if username is available for registration")
    public ResponseEntity<ApiResponse<Boolean>> checkUsernameAvailability(@PathVariable String username) {
        // Implementation will be added in UserService
        return ResponseEntity.ok(ApiResponse.success(true));
    }

    @GetMapping("/check-email/{email}")
    @Operation(summary = "Check email availability", description = "Check if email is available for registration")
    public ResponseEntity<ApiResponse<Boolean>> checkEmailAvailability(@PathVariable String email) {
        // Implementation will be added in UserService
        return ResponseEntity.ok(ApiResponse.success(true));
    }
}
