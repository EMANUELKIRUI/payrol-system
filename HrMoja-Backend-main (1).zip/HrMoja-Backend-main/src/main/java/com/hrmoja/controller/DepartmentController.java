package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.settings.DepartmentDto;
import com.hrmoja.service.DepartmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/settings/departments")
@RequiredArgsConstructor
@Tag(name = "Settings - Departments", description = "Department management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class DepartmentController {

    private final DepartmentService departmentService;

    @GetMapping("/organization/{organizationId}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get departments by organization")
    public ResponseEntity<ApiResponse<List<DepartmentDto>>> getDepartmentsByOrganization(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(departmentService.getDepartmentsByOrganization(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/active")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get active departments by organization")
    public ResponseEntity<ApiResponse<List<DepartmentDto>>> getActiveDepartments(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(departmentService.getActiveDepartmentsByOrganization(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/root")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get root departments (top-level)")
    public ResponseEntity<ApiResponse<List<DepartmentDto>>> getRootDepartments(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(departmentService.getRootDepartments(organizationId)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get department by ID")
    public ResponseEntity<ApiResponse<DepartmentDto>> getDepartmentById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(departmentService.getDepartmentById(id)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Create department")
    public ResponseEntity<ApiResponse<DepartmentDto>> createDepartment(@Valid @RequestBody DepartmentDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Department created successfully", departmentService.createDepartment(dto)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Update department")
    public ResponseEntity<ApiResponse<DepartmentDto>> updateDepartment(@PathVariable Long id, @Valid @RequestBody DepartmentDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Department updated successfully", departmentService.updateDepartment(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Delete department")
    public ResponseEntity<ApiResponse<Void>> deleteDepartment(@PathVariable Long id) {
        departmentService.deleteDepartment(id);
        return ResponseEntity.ok(ApiResponse.success("Department deactivated successfully", null));
    }
}
