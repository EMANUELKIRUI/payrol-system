package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.dashboard.DashboardMetricsDto;
import com.hrmoja.security.OrganizationContext;
import com.hrmoja.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Dashboard Controller
 */
@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Dashboard metrics and analytics")
@SecurityRequirement(name = "bearerAuth")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/metrics")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get dashboard metrics", description = "Get organization dashboard metrics and analytics")
    public ResponseEntity<ApiResponse<DashboardMetricsDto>> getDashboardMetrics() {
        Long organizationId = OrganizationContext.getCurrentOrganizationId();
        if (organizationId == null) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Organization ID is required"));
        }
        
        DashboardMetricsDto metrics = dashboardService.getOrganizationMetrics(organizationId);
        return ResponseEntity.ok(ApiResponse.success("Dashboard metrics retrieved successfully", metrics));
    }
}
