package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.payroll.PayrollComponentDto;
import com.hrmoja.service.PayrollComponentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payroll/components")
@RequiredArgsConstructor
@Tag(name = "Payroll Components", description = "Payroll component management")
@SecurityRequirement(name = "bearerAuth")
public class PayrollComponentController {

    private final PayrollComponentService componentService;

    @PostMapping
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Create payroll component")
    public ResponseEntity<ApiResponse<PayrollComponentDto>> createComponent(@Valid @RequestBody PayrollComponentDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Component created", componentService.createComponent(dto)));
    }

    @GetMapping("/organization/{organizationId}")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<List<PayrollComponentDto>>> getByOrganization(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(componentService.getComponentsByOrganization(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/active")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<List<PayrollComponentDto>>> getActive(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(componentService.getActiveComponents(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/category/{category}")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<List<PayrollComponentDto>>> getByCategory(
            @PathVariable Long organizationId, @PathVariable String category) {
        return ResponseEntity.ok(ApiResponse.success(componentService.getComponentsByCategory(organizationId, category)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<PayrollComponentDto>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(componentService.getComponentById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    public ResponseEntity<ApiResponse<PayrollComponentDto>> update(@PathVariable Long id, @Valid @RequestBody PayrollComponentDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Component updated", componentService.updateComponent(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        componentService.deleteComponent(id);
        return ResponseEntity.ok(ApiResponse.success("Component deactivated", null));
    }
}
