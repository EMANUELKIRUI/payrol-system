package com.hrmoja.service;

import com.hrmoja.dto.settings.*;
import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Settings Service - handles all reference data management
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SettingsService {

    private final PayFrequencyRepository payFrequencyRepository;
    private final EmploymentTypeRepository employmentTypeRepository;
    private final PaymentMethodRepository paymentMethodRepository;
    private final JobTitleRepository jobTitleRepository;
    private final EmployeeGradeRepository employeeGradeRepository;
    private final BankRepository bankRepository;
    private final BankBranchRepository bankBranchRepository;
    private final OrganizationRepository organizationRepository;
    private final CountryRepository countryRepository;
    private final PayrollComponentTypeRepository payrollComponentTypeRepository;

    // PAY FREQUENCY METHODS
    @Transactional(readOnly = true)
    public List<SimpleDto> getAllPayFrequencies() {
        return payFrequencyRepository.findAll().stream()
                .map(this::mapPayFrequencyToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<SimpleDto> getActivePayFrequencies() {
        return payFrequencyRepository.findByIsActiveTrue().stream()
                .map(this::mapPayFrequencyToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public SimpleDto createPayFrequency(SimpleDto dto) {
        if (payFrequencyRepository.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Pay frequency code already exists");
        }

        PayFrequency entity = PayFrequency.builder()
                .name(dto.getName())
                .code(dto.getCode())
                .description(dto.getDescription())
                .periodsPerYear(dto.getPeriodsPerYear())
                .isActive(true)
                .build();

        return mapPayFrequencyToDto(payFrequencyRepository.save(entity));
    }

    // EMPLOYMENT TYPE METHODS
    @Transactional(readOnly = true)
    public List<SimpleDto> getAllEmploymentTypes() {
        return employmentTypeRepository.findAll().stream()
                .map(this::mapEmploymentTypeToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<SimpleDto> getActiveEmploymentTypes() {
        return employmentTypeRepository.findByIsActiveTrue().stream()
                .map(this::mapEmploymentTypeToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public SimpleDto createEmploymentType(SimpleDto dto) {
        if (employmentTypeRepository.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Employment type code already exists");
        }

        EmploymentType entity = EmploymentType.builder()
                .name(dto.getName())
                .code(dto.getCode())
                .description(dto.getDescription())
                .isActive(true)
                .build();

        return mapEmploymentTypeToDto(employmentTypeRepository.save(entity));
    }

    // PAYMENT METHOD METHODS
    @Transactional(readOnly = true)
    public List<SimpleDto> getAllPaymentMethods() {
        return paymentMethodRepository.findAll().stream()
                .map(this::mapPaymentMethodToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<SimpleDto> getActivePaymentMethods() {
        return paymentMethodRepository.findByIsActiveTrue().stream()
                .map(this::mapPaymentMethodToDto)
                .collect(Collectors.toList());
    }

    // JOB TITLE METHODS
    @Transactional(readOnly = true)
    public List<JobTitleDto> getJobTitlesByOrganization(Long organizationId) {
        return jobTitleRepository.findByOrganizationId(organizationId).stream()
                .map(this::mapJobTitleToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public JobTitleDto createJobTitle(JobTitleDto dto) {
        Organization org = organizationRepository.findById(dto.getOrganizationId())
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        if (dto.getCode() != null && jobTitleRepository.existsByOrganizationIdAndCode(dto.getOrganizationId(), dto.getCode())) {
            throw new IllegalArgumentException("Job title code already exists in this organization");
        }

        JobTitle entity = JobTitle.builder()
                .organization(org)
                .title(dto.getTitle())
                .code(dto.getCode())
                .description(dto.getDescription())
                .level(dto.getLevel())
                .isActive(true)
                .build();

        return mapJobTitleToDto(jobTitleRepository.save(entity));
    }

    @Transactional
    public JobTitleDto updateJobTitle(Long id, JobTitleDto dto) {
        JobTitle entity = jobTitleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job title not found with id: " + id));
        
        entity.setTitle(dto.getTitle());
        entity.setCode(dto.getCode());
        entity.setDescription(dto.getDescription());
        entity.setLevel(dto.getLevel());
        entity.setActive(dto.isActive());
        
        return mapJobTitleToDto(jobTitleRepository.save(entity));
    }

    @Transactional
    public void deleteJobTitle(Long id) {
        JobTitle entity = jobTitleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job title not found with id: " + id));
        
        entity.setActive(false);
        jobTitleRepository.save(entity);
        log.info("Job title deactivated: {}", entity.getTitle());
    }

    // EMPLOYEE GRADE METHODS
    @Transactional(readOnly = true)
    public List<EmployeeGradeDto> getGradesByOrganization(Long organizationId) {
        return employeeGradeRepository.findByOrganizationId(organizationId).stream()
                .map(this::mapGradeToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public EmployeeGradeDto createGrade(EmployeeGradeDto dto) {
        Organization org = organizationRepository.findById(dto.getOrganizationId())
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        if (dto.getCode() != null && employeeGradeRepository.existsByOrganizationIdAndCode(dto.getOrganizationId(), dto.getCode())) {
            throw new IllegalArgumentException("Grade code already exists in this organization");
        }

        EmployeeGrade entity = EmployeeGrade.builder()
                .organization(org)
                .name(dto.getName())
                .code(dto.getCode())
                .level(dto.getLevel())
                .minSalary(dto.getMinSalary())
                .maxSalary(dto.getMaxSalary())
                .description(dto.getDescription())
                .isActive(true)
                .build();

        return mapGradeToDto(employeeGradeRepository.save(entity));
    }

    // BANK METHODS
    @Transactional(readOnly = true)
    public List<BankDto> getBanksByCountry(Long countryId) {
        return bankRepository.findByCountryId(countryId).stream()
                .map(this::mapBankToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public BankDto createBank(BankDto dto) {
        Country country = countryRepository.findById(dto.getCountryId())
                .orElseThrow(() -> new ResourceNotFoundException("Country not found"));

        Bank entity = Bank.builder()
                .country(country)
                .name(dto.getName())
                .code(dto.getCode())
                .swiftCode(dto.getSwiftCode())
                .isActive(true)
                .build();

        return mapBankToDto(bankRepository.save(entity));
    }

    // MAPPING METHODS
    private SimpleDto mapPayFrequencyToDto(PayFrequency entity) {
        return SimpleDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .code(entity.getCode())
                .description(entity.getDescription())
                .periodsPerYear(entity.getPeriodsPerYear())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private SimpleDto mapEmploymentTypeToDto(EmploymentType entity) {
        return SimpleDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .code(entity.getCode())
                .description(entity.getDescription())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private SimpleDto mapPaymentMethodToDto(PaymentMethod entity) {
        return SimpleDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .code(entity.getCode())
                .description(entity.getDescription())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private JobTitleDto mapJobTitleToDto(JobTitle entity) {
        return JobTitleDto.builder()
                .id(entity.getId())
                .organizationId(entity.getOrganization().getId())
                .title(entity.getTitle())
                .code(entity.getCode())
                .description(entity.getDescription())
                .level(entity.getLevel())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private EmployeeGradeDto mapGradeToDto(EmployeeGrade entity) {
        return EmployeeGradeDto.builder()
                .id(entity.getId())
                .organizationId(entity.getOrganization().getId())
                .name(entity.getName())
                .code(entity.getCode())
                .level(entity.getLevel())
                .minSalary(entity.getMinSalary())
                .maxSalary(entity.getMaxSalary())
                .description(entity.getDescription())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    private BankDto mapBankToDto(Bank entity) {
        return BankDto.builder()
                .id(entity.getId())
                .countryId(entity.getCountry().getId())
                .countryName(entity.getCountry().getName())
                .name(entity.getName())
                .code(entity.getCode())
                .swiftCode(entity.getSwiftCode())
                .isActive(entity.isActive())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }

    // COMPONENT TYPE METHODS
    @Transactional(readOnly = true)
    public List<ComponentTypeDto> getAllComponentTypes() {
        return payrollComponentTypeRepository.findAll().stream()
                .map(this::mapComponentTypeToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComponentTypeDto> getActiveComponentTypes() {
        return payrollComponentTypeRepository.findByIsActiveTrue().stream()
                .map(this::mapComponentTypeToDto)
                .collect(Collectors.toList());
    }

    private ComponentTypeDto mapComponentTypeToDto(PayrollComponentType entity) {
        return ComponentTypeDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .code(entity.getCode())
                .description(entity.getDescription())
                .calculationCategory(entity.getCalculationCategory())
                .isSystemType(entity.isSystemType())
                .isActive(entity.isActive())
                .build();
    }
}
