package com.hrmoja.service;

import com.hrmoja.entity.PayrollRecord;
import com.hrmoja.repository.PayrollRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * Excel Report Generation Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ExcelReportService {

    private final PayrollRecordRepository recordRepository;

    /**
     * Generate Excel payroll report
     */
    public byte[] generatePayrollExcelReport(Long periodId) {
        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Payroll Report");

            // Create styles
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle currencyStyle = createCurrencyStyle(workbook);

            // Create header row
            Row headerRow = sheet.createRow(0);
            String[] headers = {
                    "Employee Number", "Employee Name", "Department", "Job Title",
                    "Basic Salary", "Allowances", "Gross Salary",
                    "PAYE", "NSSF", "LST", "Total Deductions", "Net Salary"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Add data rows
            int rowNum = 1;
            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            for (PayrollRecord record : records) {
                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(record.getEmployeeNumber());
                row.createCell(1).setCellValue(record.getEmployeeName());
                row.createCell(2).setCellValue(record.getDepartmentName() != null ? record.getDepartmentName() : "");
                row.createCell(3).setCellValue(record.getJobTitle() != null ? record.getJobTitle() : "");

                createCurrencyCell(row, 4, record.getBasicSalary(), currencyStyle);
                createCurrencyCell(row, 5, record.getTotalAllowances(), currencyStyle);
                createCurrencyCell(row, 6, record.getGrossSalary(), currencyStyle);
                createCurrencyCell(row, 7, record.getPayeTax(), currencyStyle);
                createCurrencyCell(row, 8, record.getNssfEmployee(), currencyStyle);
                createCurrencyCell(row, 9, record.getLstDeduction(), currencyStyle);
                createCurrencyCell(row, 10, record.getTotalDeductions(), currencyStyle);
                createCurrencyCell(row, 11, record.getNetSalary(), currencyStyle);

                totalGross = totalGross.add(record.getGrossSalary());
                totalNet = totalNet.add(record.getNetSalary());
            }

            // Add total row
            Row totalRow = sheet.createRow(rowNum);
            Cell totalLabelCell = totalRow.createCell(0);
            totalLabelCell.setCellValue("TOTAL");
            totalLabelCell.setCellStyle(headerStyle);

            createCurrencyCell(totalRow, 6, totalGross, headerStyle);
            createCurrencyCell(totalRow, 11, totalNet, headerStyle);

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(baos);
            log.info("Excel report generated for period: {}", periodId);
            return baos.toByteArray();

        } catch (IOException e) {
            log.error("Error generating Excel report: {}", e.getMessage());
            throw new RuntimeException("Failed to generate Excel report", e);
        }
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private CellStyle createCurrencyStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("#,##0.00"));
        return style;
    }

    private void createCurrencyCell(Row row, int columnIndex, BigDecimal value, CellStyle style) {
        Cell cell = row.createCell(columnIndex);
        cell.setCellValue(value.doubleValue());
        cell.setCellStyle(style);
    }
}
