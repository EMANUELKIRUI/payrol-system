package com.hrmoja.service;

import com.hrmoja.dto.bank.BankDto;
import com.hrmoja.entity.Bank;
import com.hrmoja.repository.BankRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Bank Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BankService {

    private final BankRepository bankRepository;

    @Transactional(readOnly = true)
    public List<BankDto> getActiveBanks() {
        return bankRepository.findByIsActiveTrue().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BankDto> getBanksByCountry(Long countryId) {
        return bankRepository.findByCountryIdAndIsActiveTrue(countryId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private BankDto mapToDto(Bank bank) {
        return BankDto.builder()
                .id(bank.getId())
                .countryId(bank.getCountry().getId())
                .name(bank.getName())
                .code(bank.getCode())
                .swiftCode(bank.getSwiftCode())
                .active(bank.isActive())
                .build();
    }
}
