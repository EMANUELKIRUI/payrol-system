package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollProcessingService {

    private final PayrollPeriodRepository periodRepository;
    private final PayrollRunRepository runRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollLineItemRepository lineItemRepository;
    private final EmployeeRepository employeeRepository;
    private final EmployeeSalaryStructureRepository employeeSalaryStructureRepository;
    private final PayrollComponentRepository componentRepository;
    private final TaxCalculationService taxCalculationService;
    private final OrganizationRepository organizationRepository;
    private final PayrollJobRepository payrollJobRepository;
    
    // Self-injection for @Transactional proxy to work on processEmployeePayroll
    @Autowired
    @Lazy
    private PayrollProcessingService self;

    /**
     * Get all payroll periods for an organization
     */
    public List<PayrollPeriod> getPeriodsByOrganization(Long organizationId) {
        return periodRepository.findByOrganizationIdOrderByStartDateDesc(organizationId);
    }
    
    /**
     * Get paginated payroll periods with search and filters
     */
    public Page<PayrollPeriod> getPeriodsPaginated(Long organizationId, String status, 
                                                    String search, String periodType,
                                                    LocalDate startDate, LocalDate endDate,
                                                    Pageable pageable) {
        Specification<PayrollPeriod> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            
            // Organization filter (mandatory)
            predicates.add(cb.equal(root.get("organization").get("id"), organizationId));
            
            // Status filter
            if (status != null && !status.isEmpty()) {
                predicates.add(cb.equal(root.get("status"), status));
            }
            
            // Period type filter
            if (periodType != null && !periodType.isEmpty()) {
                predicates.add(cb.equal(root.get("periodType"), periodType));
            }
            
            // Search filter (search in period name)
            if (search != null && !search.isEmpty()) {
                String searchPattern = "%" + search.toLowerCase() + "%";
                predicates.add(cb.like(cb.lower(root.get("periodName")), searchPattern));
            }
            
            // Date range filter
            if (startDate != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("startDate"), startDate));
            }
            if (endDate != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("endDate"), endDate));
            }
            
            // Exclude deleted periods
            predicates.add(cb.notEqual(root.get("status"), "DELETED"));
            
            return cb.and(predicates.toArray(new Predicate[0]));
        };
        
        return periodRepository.findAll(spec, pageable);
    }

    /**
     * Get payroll period by ID
     */
    public PayrollPeriod getPeriodById(Long periodId) {
        return periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));
    }

    /**
     * Get employee payroll records for a period
     */
    public List<EmployeePayrollRecord> getPayrollRecordsByPeriod(Long periodId) {
        return recordRepository.findByPayrollPeriodId(periodId);
    }

    /**
     * Get payroll line items for an employee record
     */
    public List<PayrollLineItem> getLineItemsByRecord(Long recordId) {
        return lineItemRepository.findByEmployeePayrollRecordId(recordId);
    }

    /**
     * Create a new payroll period
     */
    @Transactional
    public PayrollPeriod createPayrollPeriod(Long organizationId, String periodName,
                                            String periodType, LocalDate startDate, 
                                            LocalDate endDate, LocalDate paymentDate) {
        // Validate dates
        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("End date must be after start date");
        }
        if (paymentDate.isBefore(endDate)) {
            throw new IllegalArgumentException("Payment date must be on or after end date");
        }

        Organization org = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        // Check for duplicate period (same org, start date, and end date)
        boolean isDuplicate = periodRepository.existsByOrganizationIdAndPeriodNameAndNotDeleted(organizationId, periodName);
        if (isDuplicate) {
            throw new IllegalArgumentException(
                String.format("A payroll period with name '%s' already exists for this organization. Please use a different name.", periodName)
            );
        }
        
        // Check for overlapping date ranges
        Optional<PayrollPeriod> existingPeriod = periodRepository.findByOrganizationAndDate(organizationId, startDate);
        if (existingPeriod.isPresent() && !"DELETED".equals(existingPeriod.get().getStatus())) {
            throw new IllegalArgumentException(
                String.format("A payroll period already exists for the date range %s to %s. Period: '%s'",
                    startDate, endDate, existingPeriod.get().getPeriodName())
            );
        }

        // Generate period code: ORG{id}-{YEAR}-{MONTH}-{TYPE}
        int year = startDate.getYear();
        int month = startDate.getMonthValue();
        String periodCode = String.format("ORG%d-%d-%02d-%s", organizationId, year, month, periodType);
        
        // Check for duplicate period code and add suffix if needed
        String finalPeriodCode = periodCode;
        int suffix = 1;
        while (periodRepository.findByPeriodCode(finalPeriodCode).isPresent()) {
            finalPeriodCode = periodCode + "-" + suffix;
            suffix++;
        }

        PayrollPeriod period = PayrollPeriod.builder()
                .organization(org)
                .periodName(periodName)
                .periodCode(finalPeriodCode)
                .periodYear(year)
                .periodMonth(month)
                .periodType(periodType)
                .startDate(startDate)
                .endDate(endDate)
                .paymentDate(paymentDate)
                .status("DRAFT")
                .totalEmployees(0)
                .totalGrossPay(BigDecimal.ZERO)
                .totalDeductions(BigDecimal.ZERO)
                .totalNetPay(BigDecimal.ZERO)
                .isActive(true)
                .build();

        PayrollPeriod saved = periodRepository.save(period);
        log.info("Created payroll period: {} [{}] for organization: {}", saved.getPeriodName(), saved.getPeriodCode(), organizationId);
        return saved;
    }

    /**
     * Initiate async payroll processing - creates job and starts processing
     * @return PayrollJob that can be used to track progress
     */
    @Transactional
    public PayrollJob initiatePayrollProcessing(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"DRAFT".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be in DRAFT status to process");
        }

        // Check if there's already an active job
        if (payrollJobRepository.hasActiveJob(periodId)) {
            throw new IllegalStateException("Payroll processing is already in progress for this period");
        }

        // Get employee count
        List<Employee> employees = employeeRepository.findByOrganizationIdAndIsActiveTrue(
                period.getOrganization().getId());

        // Create job record
        PayrollJob job = PayrollJob.builder()
                .payrollPeriod(period)
                .status(PayrollJob.JobStatus.QUEUED)
                .totalEmployees(employees.size())
                .processedEmployees(0)
                .failedEmployees(0)
                .progressPercentage(0)
                .startedBy(userId)
                .build();
        job = payrollJobRepository.save(job);

        // Start async processing
        log.info("Starting async payroll processing for period {} with {} employees", periodId, employees.size());
        processPayrollAsync(periodId, userId, job.getId());

        return job;
    }

    /**
     * Async payroll processing - runs in background thread
     */
    @org.springframework.scheduling.annotation.Async("payrollTaskExecutor")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processPayrollAsync(Long periodId, Long userId, Long jobId) {
        PayrollJob job = payrollJobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll job not found"));

        try {
            // Update job status to processing
            job.setStatus(PayrollJob.JobStatus.PROCESSING);
            job.setStartedAt(LocalDateTime.now());
            payrollJobRepository.save(job);

            // Process payroll
            processPayrollInternal(periodId, userId, jobId);

            // Mark as completed
            job = payrollJobRepository.findById(jobId).orElseThrow();
            job.setStatus(PayrollJob.JobStatus.COMPLETED);
            job.setCompletedAt(LocalDateTime.now());
            payrollJobRepository.save(job);

            log.info("Payroll processing completed successfully for period {}", periodId);

        } catch (Exception e) {
            log.error("Payroll processing failed for period {}: {}", periodId, e.getMessage(), e);
            
            // Mark job as failed
            job = payrollJobRepository.findById(jobId).orElseThrow();
            job.setStatus(PayrollJob.JobStatus.FAILED);
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(LocalDateTime.now());
            payrollJobRepository.save(job);
        }
    }

    /**
     * Internal payroll processing with progress tracking
     * No @Transactional - each employee processes independently to prevent batch rollback
     */
    private void processPayrollInternal(Long periodId, Long processedByUserId, Long jobId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"DRAFT".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be in DRAFT status to process");
        }

        // Create new payroll run
        Integer runNumber = getNextRunNumber(periodId);
        PayrollRun run = PayrollRun.builder()
                .payrollPeriod(period)
                .runNumber(runNumber)
                .runType("REGULAR")
                .status("PROCESSING")
                .totalEmployeesProcessed(0)
                .totalEmployeesFailed(0)
                .totalGrossPay(BigDecimal.ZERO)
                .totalDeductions(BigDecimal.ZERO)
                .totalNetPay(BigDecimal.ZERO)
                .processingStartedAt(LocalDateTime.now())
                .build();
        run = runRepository.save(run);

        // Update period status
        period.setStatus("PROCESSING");
        periodRepository.save(period);

        // Get all active employees
        List<Employee> employees = employeeRepository.findByOrganizationIdAndIsActiveTrue(
                period.getOrganization().getId());

        int processed = 0;
        int failed = 0;
        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;

        for (Employee employee : employees) {
            try {
                // Use self to invoke @Transactional proxy - each employee gets independent transaction
                EmployeePayrollRecord record = self.processEmployeePayroll(period, run, employee);
                processed++;
                totalGross = totalGross.add(record.getGrossSalary());
                totalDeductions = totalDeductions.add(record.getTotalDeductions());
                totalNet = totalNet.add(record.getNetSalary());
                
                // Update job progress every 5 employees or on last employee
                if (processed % 5 == 0 || processed == employees.size()) {
                    updateJobProgress(jobId, processed, failed);
                }
            } catch (Exception e) {
                failed++;
                log.error("Error processing employee {}: {}", employee.getEmployeeNumber(), e.getMessage(), e);
                
                // Update job progress on failure too
                if ((processed + failed) % 5 == 0 || (processed + failed) == employees.size()) {
                    updateJobProgress(jobId, processed, failed);
                }
            }
        }

        // Update run totals
        run.setTotalEmployeesProcessed(processed);
        run.setTotalEmployeesFailed(failed);
        run.setTotalGrossPay(totalGross);
        run.setTotalDeductions(totalDeductions);
        run.setTotalNetPay(totalNet);
        run.setStatus("COMPLETED");
        run.setProcessingCompletedAt(LocalDateTime.now());
        run = runRepository.save(run);

        // Update period (status stays PROCESSING until approved through workflow)
        period.setTotalEmployees(employees.size());
        period.setTotalGrossPay(totalGross);
        period.setTotalDeductions(totalDeductions);
        period.setTotalNetPay(totalNet);
        // Keep status as PROCESSING - will move to PREPARED/REVIEWED/APPROVED via approval workflow
        period.setProcessedBy(processedByUserId);
        period.setProcessedAt(LocalDateTime.now());
        periodRepository.save(period);

        log.info("Payroll processing completed. Processed: {}, Failed: {}", processed, failed);
    }

    private Integer getNextRunNumber(Long periodId) {
        return runRepository.findFirstByPayrollPeriodIdOrderByRunNumberDesc(periodId)
                .map(r -> r.getRunNumber() + 1)
                .orElse(1);
    }

    /**
     * Update job progress in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateJobProgress(Long jobId, int processed, int failed) {
        PayrollJob job = payrollJobRepository.findById(jobId).orElse(null);
        if (job != null) {
            job.setProcessedEmployees(processed);
            job.setFailedEmployees(failed);
            payrollJobRepository.save(job);
            log.debug("Updated job progress: {}/{} employees processed, {} failed", 
                processed, job.getTotalEmployees(), failed);
        }
    }

    /**
     * Get job status for a payroll period
     */
    public PayrollJob getJobStatus(Long periodId) {
        return payrollJobRepository.findFirstByPayrollPeriodIdOrderByCreatedAtDesc(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("No payroll job found for this period"));
    }

    /**
     * Process individual employee payroll
     * Each employee has independent transaction - failure rolls back only this employee
     * Caller catches exceptions to continue processing remaining employees
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public EmployeePayrollRecord processEmployeePayroll(PayrollPeriod period, PayrollRun run, Employee employee) {
        // Check if record already exists for this period
        EmployeePayrollRecord record = recordRepository
                .findByPayrollPeriodIdAndEmployeeId(period.getId(), employee.getId())
                .orElse(new EmployeePayrollRecord());

        // Set basic employee information
        record.setPayrollPeriod(period);
        record.setPayrollRun(run);
        record.setEmployee(employee);
        record.setEmployeeName(employee.getFirstName() + " " + employee.getLastName());
        record.setEmployeeNumber(employee.getEmployeeNumber());
        record.setDepartmentName(employee.getDepartment() != null ? employee.getDepartment().getName() : null);
        record.setPositionTitle(employee.getJobTitle() != null ? employee.getJobTitle().getTitle() : "");

        // Get employee salary structure
        EmployeeSalaryStructure salary = employeeSalaryStructureRepository.findCurrentByEmployeeId(employee.getId())
                .orElseThrow(() -> new IllegalStateException(
                        "No active salary found for employee: " + employee.getEmployeeNumber()));

        BigDecimal basicSalary = BigDecimal.valueOf(salary.getBasicSalary());
        record.setBasicSalary(basicSalary);

        // Get organization country code (ISO 3166-1 alpha-3: UGA, KEN, TZA, RWA)
        String countryCode = period.getOrganization().getCountry() != null 
                ? period.getOrganization().getCountry().getCode() 
                : "UGA"; // Default to Uganda

        // Calculate totals - we'll build line items as we go
        BigDecimal totalEarnings = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;
        BigDecimal totalStatutory = BigDecimal.ZERO;
        BigDecimal totalTaxes = BigDecimal.ZERO;

        // Get all active payroll components for the organization
        List<PayrollComponent> components = componentRepository
                .findByOrganizationIdAndIsActiveTrue(period.getOrganization().getId());

        // Calculate earnings first (don't save yet)
        for (PayrollComponent component : components) {
            if ("EARNING".equals(component.getComponentType().getCalculationCategory())) {
                BigDecimal amount = calculateComponentAmount(component, basicSalary, BigDecimal.ZERO);
                if (amount.compareTo(BigDecimal.ZERO) > 0) {
                    totalEarnings = totalEarnings.add(amount);
                }
            }
        }

        BigDecimal grossSalary = totalEarnings;
        record.setGrossSalary(grossSalary);
        record.setTotalEarnings(totalEarnings);

        // Calculate pensionable income (for NSSF)
        BigDecimal pensionableIncome = grossSalary; // In Uganda, all gross is pensionable
        record.setPensionableIncome(pensionableIncome);

        // Calculate statutory deductions (just amounts, don't create entities yet)
        BigDecimal nssfEmployee = taxCalculationService.calculateNSSFEmployee(grossSalary, countryCode);
        totalStatutory = totalStatutory.add(nssfEmployee);

        BigDecimal lst = taxCalculationService.calculateLST(countryCode);
        if (lst.compareTo(BigDecimal.ZERO) > 0) {
            totalStatutory = totalStatutory.add(lst);
        }

        // Calculate Taxable Income (Gross - NSSF - LST)
        BigDecimal taxableIncome = taxCalculationService.calculateTaxableIncome(grossSalary, nssfEmployee, lst);
        record.setTaxableIncome(taxableIncome);

        // Calculate PAYE Tax
        BigDecimal paye = taxCalculationService.calculatePAYE(taxableIncome, 
                period.getOrganization().getId(), countryCode);
        totalTaxes = totalTaxes.add(paye);

        // Calculate voluntary deductions
        for (PayrollComponent component : components) {
            if ("DEDUCTION".equals(component.getComponentType().getCalculationCategory())) {
                BigDecimal amount = calculateComponentAmount(component, basicSalary, grossSalary);
                if (amount.compareTo(BigDecimal.ZERO) > 0) {
                    totalDeductions = totalDeductions.add(amount);
                }
            }
        }

        // Calculate totals
        BigDecimal allDeductions = totalStatutory.add(totalTaxes).add(totalDeductions);
        BigDecimal netSalary = grossSalary.subtract(allDeductions);

        record.setTotalStatutory(totalStatutory);
        record.setTotalTaxes(totalTaxes);
        record.setTotalDeductions(allDeductions);
        record.setNetSalary(netSalary);
        record.setStatus("CALCULATED");

        // Save record FIRST - this commits it and gives it an ID
        record = recordRepository.save(record);
        recordRepository.flush(); // Force flush to ensure ID is assigned

        // NOW create and save line items immediately (no list accumulation)
        // This prevents any line items from being in memory if an exception occurs
        
        // 1. Save earnings
        for (PayrollComponent component : components) {
            if ("EARNING".equals(component.getComponentType().getCalculationCategory())) {
                BigDecimal amount = calculateComponentAmount(component, basicSalary, BigDecimal.ZERO);
                if (amount.compareTo(BigDecimal.ZERO) > 0) {
                    PayrollLineItem lineItem = createLineItem(record, component, amount, 0);
                    lineItem.setEmployeePayrollRecord(record);
                    lineItemRepository.save(lineItem);
                }
            }
        }

        // 2. Save statutory deductions
        PayrollLineItem nssfLineItem = createStatutoryLineItem(record, "NSSF Employee", "NSSF_EMP", 
                nssfEmployee, "STATUTORY", 20);
        nssfLineItem.setEmployeePayrollRecord(record);
        lineItemRepository.save(nssfLineItem);

        if (lst.compareTo(BigDecimal.ZERO) > 0) {
            PayrollLineItem lstLineItem = createStatutoryLineItem(record, "Local Service Tax", "LST", 
                    lst, "STATUTORY", 23);
            lstLineItem.setEmployeePayrollRecord(record);
            lineItemRepository.save(lstLineItem);
        }

        // 3. Save PAYE
        PayrollLineItem payeLineItem = createStatutoryLineItem(record, "PAYE Tax", "PAYE", 
                paye, "TAX", 22);
        payeLineItem.setEmployeePayrollRecord(record);
        lineItemRepository.save(payeLineItem);

        // 4. Save voluntary deductions
        for (PayrollComponent component : components) {
            if ("DEDUCTION".equals(component.getComponentType().getCalculationCategory())) {
                BigDecimal amount = calculateComponentAmount(component, basicSalary, grossSalary);
                if (amount.compareTo(BigDecimal.ZERO) > 0) {
                    PayrollLineItem lineItem = createLineItem(record, component, amount, 30);
                    lineItem.setEmployeePayrollRecord(record);
                    lineItemRepository.save(lineItem);
                }
            }
        }

        log.info("Processed payroll for employee: {}. Gross: {}, Net: {}", 
                employee.getEmployeeNumber(), grossSalary, netSalary);
        return record;
    }

    /**
     * Calculate component amount based on calculation method
     */
    private BigDecimal calculateComponentAmount(PayrollComponent component, 
                                               BigDecimal basicSalary, 
                                               BigDecimal grossSalary) {
        String method = component.getCalculationMethod();
        
        if ("FIXED".equals(method)) {
            return component.getFixedAmount() != null ? component.getFixedAmount() : BigDecimal.ZERO;
        }
        
        if ("PERCENTAGE".equals(method)) {
            BigDecimal basis = getBasisAmount(component.getCalculationBasis(), basicSalary, grossSalary);
            BigDecimal percentage = component.getPercentageValue() != null ? 
                    component.getPercentageValue() : BigDecimal.ZERO;
            BigDecimal amount = basis.multiply(percentage).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            
            // Apply max amount if specified
            if (component.getMaxAmount() != null && component.getMaxAmount().compareTo(BigDecimal.ZERO) > 0) {
                amount = amount.min(component.getMaxAmount());
            }
            return amount;
        }
        
        // FORMULA and RANGE calculations can be added later
        return BigDecimal.ZERO;
    }
    
    private BigDecimal getBasisAmount(String basis, BigDecimal basicSalary, BigDecimal grossSalary) {
        if ("BASIC_SALARY".equals(basis)) {
            return basicSalary;
        }
        if ("GROSS_SALARY".equals(basis)) {
            return grossSalary;
        }
        return basicSalary; // Default to basic
    }
    
    /**
     * Create payroll line item from component
     */
    private PayrollLineItem createLineItem(EmployeePayrollRecord record, 
                                          PayrollComponent component, 
                                          BigDecimal amount,
                                          int baseDisplayOrder) {
        // DO NOT set employeePayrollRecord here - it will be set after record is saved
        // This prevents Hibernate session corruption with null IDs
        return PayrollLineItem.builder()
                .component(component)
                .componentName(component.getName())
                .componentCode(component.getCode())
                .componentCategory(component.getComponentType().getCalculationCategory())
                .calculationMethod(component.getCalculationMethod())
                .calculationBasis(component.getCalculationBasis())
                .rateOrAmount(component.getPercentageValue() != null ? 
                        component.getPercentageValue() : component.getFixedAmount())
                .quantity(BigDecimal.ONE)
                .amount(amount)
                .isTaxable(component.isTaxable())
                .isPensionable(component.isPensionable())
                .isStatutory(component.isStatutory())
                .displayOrder(baseDisplayOrder + component.getPriorityOrder())
                .build();
    }
    
    /**
     * Create statutory line item (NSSF, PAYE, LST)
     */
    private PayrollLineItem createStatutoryLineItem(EmployeePayrollRecord record,
                                                    String name,
                                                    String code,
                                                    BigDecimal amount,
                                                    String category,
                                                    int displayOrder) {
        // DO NOT set employeePayrollRecord here - it will be set after record is saved
        // This prevents Hibernate session corruption with null IDs
        return PayrollLineItem.builder()
                .component(null)
                .componentName(name)
                .componentCode(code)
                .componentCategory(category)
                .calculationMethod("FORMULA")
                .amount(amount)
                .quantity(BigDecimal.ONE)
                .isTaxable(false)
                .isPensionable(false)
                .isStatutory(true)
                .displayOrder(displayOrder)
                .build();
    }

    /**
     * Approve payroll period
     */
    @Transactional
    public void approvePayrollPeriod(Long periodId, Long approvedByUserId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Period already approved or in wrong status");
        }

        period.setApprovedBy(approvedByUserId);
        period.setApprovedAt(LocalDateTime.now());
        periodRepository.save(period);
        
        log.info("Payroll period {} approved by user {}", periodId, approvedByUserId);
    }

    /**
     * Mark payroll as paid
     */
    @Transactional
    public void markPayrollAsPaid(Long periodId, Long paidByUserId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only approved periods can be marked as paid");
        }

        period.setStatus("PAID");
        periodRepository.save(period);
        
        // Update all employee records to paid
        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);
        for (EmployeePayrollRecord record : records) {
            record.setPaid(true);
            record.setPaymentDate(LocalDateTime.now());
            recordRepository.save(record);
        }
        
        log.info("Payroll period {} marked as paid", periodId);
    }

    /**
     * Recalculate payroll for a period (creates new run)
     */
    @Transactional
    public PayrollRun recalculatePayroll(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        // Allow recalculation at DRAFT, PROCESSING, and PREPARED (Level 1) stages
        if ("REVIEWED".equals(period.getStatus()) || 
            "APPROVED".equals(period.getStatus()) || 
            "PAID".equals(period.getStatus()) || 
            "CLOSED".equals(period.getStatus())) {
            throw new IllegalStateException("Cannot recalculate after Level 2 review. Current status: " + period.getStatus());
        }

        // Delete existing records for this period
        List<EmployeePayrollRecord> existingRecords = recordRepository.findByPayrollPeriodId(periodId);
        for (EmployeePayrollRecord record : existingRecords) {
            lineItemRepository.deleteByEmployeePayrollRecordId(record.getId());
        }
        recordRepository.deleteAll(existingRecords);
        
        // Reset period status
        period.setStatus("DRAFT");
        periodRepository.save(period);
        
        // Process again using async processing
        PayrollJob job = initiatePayrollProcessing(periodId, userId);
        log.info("Recalculation started with job ID: {}", job.getId());
        
        // Return a mock PayrollRun for backward compatibility
        // The actual processing is happening asynchronously
        return PayrollRun.builder()
                .payrollPeriod(period)
                .runNumber(getNextRunNumber(periodId))
                .runType("RECALCULATION")
                .status("PROCESSING")
                .build();
    }

    /**
     * Close payroll period (final lock)
     */
    @Transactional
    public void closePayrollPeriod(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"PAID".equals(period.getStatus())) {
            throw new IllegalStateException("Only paid periods can be closed");
        }

        period.setStatus("CLOSED");
        period.setActive(false);
        periodRepository.save(period);
        
        log.info("Payroll period {} closed and locked", periodId);
    }

    /**
     * Update payroll period (only DRAFT periods)
     */
    @Transactional
    public PayrollPeriod updatePayrollPeriod(Long periodId, String periodName,
                                             LocalDate startDate, LocalDate endDate, 
                                             LocalDate paymentDate) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"DRAFT".equals(period.getStatus())) {
            throw new IllegalStateException("Only draft periods can be updated");
        }

        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("End date must be after start date");
        }
        if (paymentDate.isBefore(endDate)) {
            throw new IllegalArgumentException("Payment date must be on or after end date");
        }

        period.setPeriodName(periodName);
        period.setStartDate(startDate);
        period.setEndDate(endDate);
        period.setPaymentDate(paymentDate);

        return periodRepository.save(period);
    }

    /**
     * Delete payroll period (only DRAFT periods)
     */
    @Transactional
    public void deletePayrollPeriod(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"DRAFT".equals(period.getStatus())) {
            throw new IllegalStateException("Only draft periods can be deleted");
        }

        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);
        for (EmployeePayrollRecord record : records) {
            lineItemRepository.deleteByEmployeePayrollRecordId(record.getId());
        }
        recordRepository.deleteAll(records);
        
        List<PayrollRun> runs = runRepository.findByPayrollPeriodId(periodId);
        runRepository.deleteAll(runs);
        
        periodRepository.delete(period);
        log.info("Period {} deleted successfully", periodId);
    }
}
