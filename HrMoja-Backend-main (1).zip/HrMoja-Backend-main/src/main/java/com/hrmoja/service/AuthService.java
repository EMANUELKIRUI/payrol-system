package com.hrmoja.service;

import com.hrmoja.dto.auth.LoginRequest;
import com.hrmoja.dto.auth.LoginResponse;
import com.hrmoja.dto.auth.RegisterRequest;
import com.hrmoja.entity.Organization;
import com.hrmoja.entity.Role;
import com.hrmoja.entity.User;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.OrganizationRepository;
import com.hrmoja.repository.RoleRepository;
import com.hrmoja.repository.UserRepository;
import com.hrmoja.security.JwtTokenProvider;
import com.hrmoja.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Authentication Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final OrganizationRepository organizationRepository;
    private final AuditLogService auditLogService;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Authenticate user and generate JWT token
     */
    @Transactional
    public LoginResponse login(LoginRequest request) {
        // Authenticate user
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Generate tokens
        String token = jwtTokenProvider.generateToken(authentication);
        String refreshToken = jwtTokenProvider.generateRefreshToken(authentication);

        // Update last login
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // Extract roles and permissions
        List<String> roles = user.getRoles().stream()
                .map(Role::getCode)
                .collect(Collectors.toList());

        // Check organization status - only for non-platform admins
        boolean isPlatformAdmin = roles.contains("SUPER_ADMIN") || roles.contains("PLATFORM_ADMIN");
        if (!isPlatformAdmin && user.getOrganizationId() != null) {
            organizationRepository.findById(user.getOrganizationId())
                    .ifPresent(org -> {
                        if (!org.isActive()) {
                            throw new IllegalStateException("Your organization has been deactivated. Please contact support.");
                        }
                    });
        }

        user.setLastLoginAt(LocalDateTime.now());
        user.setFailedLoginAttempts(0);
        userRepository.save(user);

        List<String> permissions = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .filter(auth -> !auth.startsWith("ROLE_"))
                .collect(Collectors.toList());

        log.info("User {} logged in successfully", request.getUsername());
        
        // Log the login activity
        auditLogService.logActivity("LOGIN");

        return LoginResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .userId(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .organizationId(user.getOrganizationId())
                .organizationName(user.getOrganizationId() != null ? 
                    organizationRepository.findById(user.getOrganizationId())
                        .map(org -> org.getName())
                        .orElse(null) : null)
                .roles(roles)
                .permissions(permissions)
                .build();
    }

    /**
     * Register new user
     */
    @Transactional
    public User register(RegisterRequest request) {
        // Check if username exists
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }

        // Check if email exists
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }

        // Create user (without organization - regular employee registration)
        // Organization will be set when employee is assigned to an organization
        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phoneNumber(request.getPhoneNumber())
                .organizationId(null) // Will be set when user is linked to organization
                .isActive(true)
                .isLocked(false)
                .isEmailVerified(false)
                .failedLoginAttempts(0)
                .build();

        // Assign default employee role
        Role employeeRole = roleRepository.findByCode("EMPLOYEE")
                .orElseThrow(() -> new ResourceNotFoundException("Default role not found"));
        
        Set<Role> roles = new HashSet<>();
        roles.add(employeeRole);
        user.setRoles(roles);

        User savedUser = userRepository.save(user);
        log.info("User {} registered successfully", request.getUsername());

        return savedUser;
    }

    /**
     * Change password
     */
    @Transactional
    public void changePassword(Long userId, String oldPassword, String newPassword) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Verify old password
        if (!passwordEncoder.matches(oldPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Current password is incorrect");
        }

        // Update password
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        user.setMustChangePassword(false);
        userRepository.save(user);

        log.info("Password changed for user {}", user.getUsername());
    }
}
