package com.hrmoja.service;

import com.hrmoja.dto.bank.BankBranchDto;
import com.hrmoja.entity.BankBranch;
import com.hrmoja.repository.BankBranchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Bank Branch Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BankBranchService {

    private final BankBranchRepository bankBranchRepository;

    @Transactional(readOnly = true)
    public List<BankBranchDto> getBranchesByBank(Long bankId) {
        return bankBranchRepository.findByBankIdAndIsActiveTrue(bankId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private BankBranchDto mapToDto(BankBranch branch) {
        return BankBranchDto.builder()
                .id(branch.getId())
                .bankId(branch.getBank().getId())
                .name(branch.getName())
                .code(branch.getCode())
                .address(branch.getAddress())
                .active(branch.isActive())
                .build();
    }
}
