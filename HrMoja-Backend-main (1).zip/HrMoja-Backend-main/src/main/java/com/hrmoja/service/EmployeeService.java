package com.hrmoja.service;

import com.hrmoja.dto.employee.EmployeeCreateRequest;
import com.hrmoja.dto.employee.EmployeeDto;
import com.hrmoja.dto.salary.EmployeeSalaryDto;
import com.hrmoja.dto.bank.EmployeeBankDetailsDto;
import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.dto.user.UserCreateRequest;
import com.hrmoja.dto.user.UserDto;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Employee Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final OrganizationRepository organizationRepository;
    private final BranchRepository branchRepository;
    private final DepartmentRepository departmentRepository;
    private final EmploymentTypeRepository employmentTypeRepository;
    private final JobTitleRepository jobTitleRepository;
    private final EmployeeGradeRepository employeeGradeRepository;
    private final CountryRepository countryRepository;
    private final UserManagementService userManagementService;
    private final RoleRepository roleRepository;
    private final EmployeeSalaryService employeeSalaryService;
    private final PayFrequencyRepository payFrequencyRepository;
    private final EmployeeBankDetailsService employeeBankDetailsService;
    private final BankRepository bankRepository;

    @Transactional
    public EmployeeDto createEmployee(EmployeeCreateRequest request) {
        // Validate organization
        Organization organization = organizationRepository.findById(request.getOrganizationId())
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        // Generate employee number
        String employeeNumber = generateEmployeeNumber(organization);

        // Build employee
        Employee employee = Employee.builder()
                .employeeNumber(employeeNumber)
                .organization(organization)
                .firstName(request.getFirstName())
                .middleName(request.getMiddleName())
                .lastName(request.getLastName())
                .dateOfBirth(request.getDateOfBirth())
                .gender(request.getGender())
                .maritalStatus(request.getMaritalStatus())
                .nationality(request.getNationality())
                .nationalId(request.getNationalId())
                .passportNumber(request.getPassportNumber())
                .personalEmail(request.getPersonalEmail())
                .workEmail(request.getWorkEmail())
                .mobilePhone(request.getMobilePhone())
                .homePhone(request.getHomePhone())
                .emergencyContactName(request.getEmergencyContactName())
                .emergencyContactPhone(request.getEmergencyContactPhone())
                .emergencyContactRelationship(request.getEmergencyContactRelationship())
                .addressLine1(request.getAddressLine1())
                .addressLine2(request.getAddressLine2())
                .city(request.getCity())
                .stateProvince(request.getStateProvince())
                .postalCode(request.getPostalCode())
                .hireDate(request.getHireDate())
                .probationEndDate(request.getProbationEndDate())
                .employmentStatus("ACTIVE")
                .isActive(true)
                .build();

        // Set optional relationships
        if (request.getBranchId() != null) {
            Branch branch = branchRepository.findById(request.getBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
            employee.setBranch(branch);
        }

        if (request.getDepartmentId() != null) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
            employee.setDepartment(department);
        }

        if (request.getCountryId() != null) {
            Country country = countryRepository.findById(request.getCountryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Country not found"));
            employee.setCountry(country);
        }

        // Set employment type
        EmploymentType employmentType = employmentTypeRepository.findById(request.getEmploymentTypeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employment type not found"));
        employee.setEmploymentType(employmentType);

        // Set job title
        JobTitle jobTitle = jobTitleRepository.findById(request.getJobTitleId())
                .orElseThrow(() -> new ResourceNotFoundException("Job title not found"));
        employee.setJobTitle(jobTitle);

        // Set grade if provided
        if (request.getEmployeeGradeId() != null) {
            EmployeeGrade grade = employeeGradeRepository.findById(request.getEmployeeGradeId())
                    .orElseThrow(() -> new ResourceNotFoundException("Employee grade not found"));
            employee.setEmployeeGrade(grade);
        }

        employee.setReportsToEmployeeId(request.getReportsToEmployeeId());

        Employee savedEmployee = employeeRepository.save(employee);
        log.info("Employee created: {} {} ({})", savedEmployee.getFirstName(), savedEmployee.getLastName(), savedEmployee.getEmployeeNumber());

        // Create user account if requested
        if (Boolean.TRUE.equals(request.getCreateUserAccount()) && request.getRoleId() != null) {
            try {
                // Validate role exists
                Role role = roleRepository.findById(request.getRoleId())
                        .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + request.getRoleId()));

                // Generate username from employee email or number
                String username = generateUsername(savedEmployee);
                String email = savedEmployee.getWorkEmail() != null ? savedEmployee.getWorkEmail() : savedEmployee.getPersonalEmail();
                
                if (email == null) {
                    log.warn("Cannot create user account for employee {} - no email provided", savedEmployee.getEmployeeNumber());
                } else {
                    // Create user account request
                    UserCreateRequest userRequest = UserCreateRequest.builder()
                            .username(username)
                            .email(email)
                            .password("ChangeMe@123") // Default password - user must change on first login
                            .firstName(savedEmployee.getFirstName())
                            .lastName(savedEmployee.getLastName())
                            .phoneNumber(savedEmployee.getMobilePhone())
                            .organizationId(organization.getId())
                            .employeeId(savedEmployee.getId())
                            .roleIds(Set.of(request.getRoleId()))
                            .mustChangePassword(true)
                            .build();

                    // Create user
                    UserDto createdUser = userManagementService.createUser(userRequest);
                    
                    // Update employee with user_id
                    savedEmployee.setUserId(createdUser.getId());
                    savedEmployee = employeeRepository.save(savedEmployee);
                    
                    log.info("User account created for employee {}: username={}", 
                            savedEmployee.getEmployeeNumber(), username);
                }
            } catch (Exception e) {
                log.error("Failed to create user account for employee {}: {}", 
                        savedEmployee.getEmployeeNumber(), e.getMessage());
                // Don't fail employee creation if user creation fails
            }
        }

        // Create salary structure if salary data is provided
        if (request.getBasicSalary() != null && request.getBasicSalary() > 0 && 
            request.getCurrencyCode() != null && request.getPayFrequencyId() != null) {
            try {
                // Validate pay frequency exists
                payFrequencyRepository.findById(request.getPayFrequencyId())
                        .orElseThrow(() -> new ResourceNotFoundException("Pay frequency not found with id: " + request.getPayFrequencyId()));

                // Create salary structure
                EmployeeSalaryDto salaryDto = EmployeeSalaryDto.builder()
                        .employeeId(savedEmployee.getId())
                        .basicSalary(request.getBasicSalary())
                        .currencyCode(request.getCurrencyCode())
                        .payFrequencyId(request.getPayFrequencyId())
                        .effectiveDate(request.getHireDate()) // Use hire date as effective date
                        .active(true)
                        .build();

                employeeSalaryService.createSalary(salaryDto);
                log.info("Salary structure created for employee {}: {} {}", 
                        savedEmployee.getEmployeeNumber(), request.getCurrencyCode(), request.getBasicSalary());
            } catch (Exception e) {
                log.error("Failed to create salary structure for employee {}: {}", 
                        savedEmployee.getEmployeeNumber(), e.getMessage());
                // Don't fail employee creation if salary creation fails
            }
        }

        // Create bank details if bank data is provided
        if (request.getBankId() != null && request.getAccountNumber() != null && 
            request.getAccountName() != null) {
            try {
                // Validate bank exists
                bankRepository.findById(request.getBankId())
                        .orElseThrow(() -> new ResourceNotFoundException("Bank not found with id: " + request.getBankId()));

                // Create bank details
                EmployeeBankDetailsDto bankDetailsDto = EmployeeBankDetailsDto.builder()
                        .employeeId(savedEmployee.getId())
                        .bankId(request.getBankId())
                        .bankBranchId(request.getBankBranchId())
                        .accountNumber(request.getAccountNumber())
                        .accountName(request.getAccountName())
                        .accountType(request.getAccountType())
                        .swiftCode(request.getSwiftCode())
                        .iban(request.getIban())
                        .primary(true) // First bank details is primary by default
                        .active(true)
                        .build();

                employeeBankDetailsService.createBankDetails(bankDetailsDto);
                log.info("Bank details created for employee {}: {}", 
                        savedEmployee.getEmployeeNumber(), request.getAccountNumber());
            } catch (Exception e) {
                log.error("Failed to create bank details for employee {}: {}", 
                        savedEmployee.getEmployeeNumber(), e.getMessage());
                // Don't fail employee creation if bank details creation fails
            }
        }

        return mapToDto(savedEmployee);
    }

    @Transactional(readOnly = true)
    public EmployeeDto getEmployeeById(Long id) {
        Employee employee = employeeRepository.findByIdWithDetails(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        return mapToDto(employee);
    }

    @Transactional(readOnly = true)
    public EmployeeDto getEmployeeByNumber(String employeeNumber) {
        Employee employee = employeeRepository.findByEmployeeNumber(employeeNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with number: " + employeeNumber));
        return mapToDto(employee);
    }

    @Transactional(readOnly = true)
    public List<EmployeeDto> getEmployeesByOrganization(Long organizationId) {
        return employeeRepository.findByOrganizationId(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<EmployeeDto> getEmployeesPaginated(Long organizationId, Pageable pageable) {
        return employeeRepository.findByOrganizationId(organizationId, pageable)
                .map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public Page<EmployeeDto> searchEmployees(Long organizationId, String searchTerm, Pageable pageable) {
        return employeeRepository.searchEmployees(organizationId, searchTerm, pageable)
                .map(this::mapToDto);
    }

    @Transactional(readOnly = true)
    public Page<EmployeeDto> searchEmployeesWithFilters(
            Long organizationId,
            String search,
            Long departmentId,
            Long branchId,
            Long employmentTypeId,
            String status,
            Boolean isActive,
            Pageable pageable) {
        return employeeRepository.searchEmployeesWithFilters(
                organizationId, search, departmentId, branchId, 
                employmentTypeId, status, isActive, pageable)
                .map(this::mapToDto);
    }

    @Transactional
    public EmployeeDto updateEmployee(Long id, EmployeeDto dto) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));

        // Update fields
        employee.setFirstName(dto.getFirstName());
        employee.setMiddleName(dto.getMiddleName());
        employee.setLastName(dto.getLastName());
        employee.setDateOfBirth(dto.getDateOfBirth());
        employee.setGender(dto.getGender());
        employee.setMaritalStatus(dto.getMaritalStatus());
        employee.setNationality(dto.getNationality());
        employee.setNationalId(dto.getNationalId());
        employee.setPassportNumber(dto.getPassportNumber());
        employee.setPersonalEmail(dto.getPersonalEmail());
        employee.setWorkEmail(dto.getWorkEmail());
        employee.setMobilePhone(dto.getMobilePhone());
        employee.setHomePhone(dto.getHomePhone());
        employee.setEmergencyContactName(dto.getEmergencyContactName());
        employee.setEmergencyContactPhone(dto.getEmergencyContactPhone());
        employee.setEmergencyContactRelationship(dto.getEmergencyContactRelationship());
        employee.setAddressLine1(dto.getAddressLine1());
        employee.setAddressLine2(dto.getAddressLine2());
        employee.setCity(dto.getCity());
        employee.setStateProvince(dto.getStateProvince());
        employee.setPostalCode(dto.getPostalCode());
        employee.setBio(dto.getBio());

        Employee updated = employeeRepository.save(employee);
        log.info("Employee updated: {}", updated.getEmployeeNumber());

        return mapToDto(updated);
    }

    @Transactional
    public void deactivateEmployee(Long id, String reason) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));

        employee.setActive(false);
        employee.setEmploymentStatus("TERMINATED");
        employee.setTerminationDate(LocalDate.now());
        employee.setTerminationReason(reason);

        employeeRepository.save(employee);
        log.info("Employee deactivated: {}", employee.getEmployeeNumber());
    }

    private String generateEmployeeNumber(Organization organization) {
        String prefix = organization.getName()
                .replaceAll("[^A-Za-z0-9]", "")
                .toUpperCase()
                .substring(0, Math.min(3, organization.getName().length()));

        long count = employeeRepository.countByOrganizationId(organization.getId());
        return String.format("%s-%05d", prefix, count + 1);
    }

    private String generateUsername(Employee employee) {
        // Generate username from first name and last name
        String baseUsername = (employee.getFirstName().toLowerCase() + "." + employee.getLastName().toLowerCase())
                .replaceAll("[^a-z0-9.]", "");
        
        // Check if username already exists and append number if needed
        String username = baseUsername;
        int counter = 1;
        while (userManagementService.usernameExists(username)) {
            username = baseUsername + counter;
            counter++;
        }
        
        return username;
    }

    private EmployeeDto mapToDto(Employee employee) {
        return EmployeeDto.builder()
                .id(employee.getId())
                .employeeNumber(employee.getEmployeeNumber())
                .organizationId(employee.getOrganization().getId())
                .branchId(employee.getBranch() != null ? employee.getBranch().getId() : null)
                .branchName(employee.getBranch() != null ? employee.getBranch().getName() : null)
                .departmentId(employee.getDepartment() != null ? employee.getDepartment().getId() : null)
                .departmentName(employee.getDepartment() != null ? employee.getDepartment().getName() : null)
                .firstName(employee.getFirstName())
                .middleName(employee.getMiddleName())
                .lastName(employee.getLastName())
                .dateOfBirth(employee.getDateOfBirth())
                .gender(employee.getGender())
                .maritalStatus(employee.getMaritalStatus())
                .nationality(employee.getNationality())
                .nationalId(employee.getNationalId())
                .passportNumber(employee.getPassportNumber())
                .personalEmail(employee.getPersonalEmail())
                .workEmail(employee.getWorkEmail())
                .mobilePhone(employee.getMobilePhone())
                .homePhone(employee.getHomePhone())
                .emergencyContactName(employee.getEmergencyContactName())
                .emergencyContactPhone(employee.getEmergencyContactPhone())
                .emergencyContactRelationship(employee.getEmergencyContactRelationship())
                .addressLine1(employee.getAddressLine1())
                .addressLine2(employee.getAddressLine2())
                .city(employee.getCity())
                .stateProvince(employee.getStateProvince())
                .postalCode(employee.getPostalCode())
                .countryId(employee.getCountry() != null ? employee.getCountry().getId() : null)
                .countryName(employee.getCountry() != null ? employee.getCountry().getName() : null)
                .hireDate(employee.getHireDate())
                .confirmationDate(employee.getConfirmationDate())
                .probationEndDate(employee.getProbationEndDate())
                .terminationDate(employee.getTerminationDate())
                .terminationReason(employee.getTerminationReason())
                .employmentTypeId(employee.getEmploymentType() != null ? employee.getEmploymentType().getId() : null)
                .employmentTypeName(employee.getEmploymentType() != null ? employee.getEmploymentType().getName() : null)
                .jobTitleId(employee.getJobTitle() != null ? employee.getJobTitle().getId() : null)
                .jobTitleName(employee.getJobTitle() != null ? employee.getJobTitle().getTitle() : null)
                .employeeGradeId(employee.getEmployeeGrade() != null ? employee.getEmployeeGrade().getId() : null)
                .employeeGradeName(employee.getEmployeeGrade() != null ? employee.getEmployeeGrade().getName() : null)
                .reportsToEmployeeId(employee.getReportsToEmployeeId())
                .employmentStatus(employee.getEmploymentStatus())
                .isActive(employee.isActive())
                .photoUrl(employee.getPhotoUrl())
                .bio(employee.getBio())
                .userId(employee.getUserId())
                .createdAt(employee.getCreatedAt())
                .updatedAt(employee.getUpdatedAt())
                .build();
    }

    public Long getEmployeeCount(Long organizationId) {
        return employeeRepository.countByOrganizationId(organizationId);
    }

    public Long getActiveEmployeeCount(Long organizationId) {
        return employeeRepository.countByOrganizationIdAndIsActiveTrue(organizationId);
    }
}
