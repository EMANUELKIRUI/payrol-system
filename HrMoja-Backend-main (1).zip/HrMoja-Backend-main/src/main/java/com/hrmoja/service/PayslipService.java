package com.hrmoja.service;

import com.hrmoja.entity.PayrollRecord;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.PayrollRecordRepository;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Payslip Generation Service
 * Generates PDF payslips for employees
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayslipService {

    private final PayrollRecordRepository payrollRecordRepository;

    /**
     * Generate PDF payslip for a payroll record
     */
    public byte[] generatePayslip(Long payrollRecordId) {
        PayrollRecord record = payrollRecordRepository.findById(payrollRecordId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll record not found"));

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(baos);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // Add company header
            addHeader(document, record);

            // Add employee details
            addEmployeeDetails(document, record);

            // Add earnings section
            addEarningsSection(document, record);

            // Add deductions section
            addDeductionsSection(document, record);

            // Add summary section
            addSummarySection(document, record);

            // Add footer
            addFooter(document);

            document.close();

            log.info("Payslip generated for employee: {}", record.getEmployeeNumber());
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("Error generating payslip for record {}: {}", payrollRecordId, e.getMessage());
            throw new RuntimeException("Failed to generate payslip", e);
        }
    }

    private void addHeader(Document document, PayrollRecord record) {
        // Company name
        Paragraph companyName = new Paragraph("HRMoja Payroll System")
                .setFontSize(18)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER);
        document.add(companyName);

        // Payslip title
        Paragraph title = new Paragraph("PAYSLIP")
                .setFontSize(16)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(10);
        document.add(title);

        // Period details
        String periodName = record.getPayrollPeriod().getPeriodName();
        Paragraph period = new Paragraph("Period: " + periodName)
                .setFontSize(12)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(period);
    }

    private void addEmployeeDetails(Document document, PayrollRecord record) {
        Table table = new Table(UnitValue.createPercentArray(new float[]{1, 1}))
                .useAllAvailableWidth()
                .setMarginBottom(15);

        table.addCell(createCell("Employee Number:", true));
        table.addCell(createCell(record.getEmployeeNumber(), false));

        table.addCell(createCell("Employee Name:", true));
        table.addCell(createCell(record.getEmployeeName(), false));

        table.addCell(createCell("Department:", true));
        table.addCell(createCell(record.getDepartmentName() != null ? record.getDepartmentName() : "N/A", false));

        table.addCell(createCell("Job Title:", true));
        table.addCell(createCell(record.getJobTitle() != null ? record.getJobTitle() : "N/A", false));

        if (record.getDaysWorked() != null) {
            table.addCell(createCell("Days Worked:", true));
            table.addCell(createCell(record.getDaysWorked() + " / " + record.getDaysInMonth(), false));
        }

        document.add(table);
    }

    private void addEarningsSection(Document document, PayrollRecord record) {
        Paragraph sectionTitle = new Paragraph("EARNINGS")
                .setFontSize(12)
                .setBold()
                .setMarginTop(10)
                .setMarginBottom(5);
        document.add(sectionTitle);

        Table table = new Table(UnitValue.createPercentArray(new float[]{3, 1}))
                .useAllAvailableWidth()
                .setMarginBottom(10);

        // Header
        table.addCell(createHeaderCell("Description"));
        table.addCell(createHeaderCell("Amount (UGX)"));

        // Basic Salary
        table.addCell(createCell("Basic Salary", false));
        table.addCell(createAmountCell(record.getBasicSalary()));

        // Allowances
        if (record.getTotalAllowances().compareTo(BigDecimal.ZERO) > 0) {
            table.addCell(createCell("Allowances", false));
            table.addCell(createAmountCell(record.getTotalAllowances()));
        }

        // Gross Salary
        table.addCell(createCell("GROSS SALARY", true));
        table.addCell(createAmountCell(record.getGrossSalary()).setBold());

        document.add(table);
    }

    private void addDeductionsSection(Document document, PayrollRecord record) {
        Paragraph sectionTitle = new Paragraph("DEDUCTIONS")
                .setFontSize(12)
                .setBold()
                .setMarginTop(10)
                .setMarginBottom(5);
        document.add(sectionTitle);

        Table table = new Table(UnitValue.createPercentArray(new float[]{3, 1}))
                .useAllAvailableWidth()
                .setMarginBottom(10);

        // Header
        table.addCell(createHeaderCell("Description"));
        table.addCell(createHeaderCell("Amount (UGX)"));

        // PAYE
        table.addCell(createCell("PAYE Tax", false));
        table.addCell(createAmountCell(record.getPayeTax()));

        // NSSF
        table.addCell(createCell("NSSF", false));
        table.addCell(createAmountCell(record.getNssfEmployee()));

        // LST
        if (record.getLstDeduction().compareTo(BigDecimal.ZERO) > 0) {
            table.addCell(createCell("LST", false));
            table.addCell(createAmountCell(record.getLstDeduction()));
        }

        // Total Deductions
        table.addCell(createCell("TOTAL DEDUCTIONS", true));
        table.addCell(createAmountCell(record.getTotalDeductions()).setBold());

        document.add(table);
    }

    private void addSummarySection(Document document, PayrollRecord record) {
        Table table = new Table(UnitValue.createPercentArray(new float[]{3, 1}))
                .useAllAvailableWidth()
                .setMarginTop(15)
                .setMarginBottom(20);

        // Net Salary
        Cell netLabel = createCell("NET SALARY", true)
                .setBackgroundColor(new DeviceRgb(46, 125, 50))
                .setFontColor(ColorConstants.WHITE)
                .setFontSize(14);
        
        Cell netAmount = createAmountCell(record.getNetSalary())
                .setBackgroundColor(new DeviceRgb(46, 125, 50))
                .setFontColor(ColorConstants.WHITE)
                .setFontSize(14)
                .setBold();

        table.addCell(netLabel);
        table.addCell(netAmount);

        document.add(table);

        // Payment details
        if (record.getBankName() != null) {
            Paragraph paymentInfo = new Paragraph("Payment Method: Bank Transfer")
                    .setFontSize(10)
                    .setMarginTop(10);
            document.add(paymentInfo);

            Paragraph bankInfo = new Paragraph("Bank: " + record.getBankName() + 
                    " | Account: " + maskAccountNumber(record.getAccountNumber()))
                    .setFontSize(10);
            document.add(bankInfo);
        }
    }

    private void addFooter(Document document) {
        Paragraph footer = new Paragraph("\n\nThis is a system-generated payslip and does not require a signature.")
                .setFontSize(9)
                .setItalic()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginTop(30);
        document.add(footer);

        Paragraph date = new Paragraph("Generated on: " + 
                java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")))
                .setFontSize(8)
                .setTextAlignment(TextAlignment.CENTER);
        document.add(date);
    }

    private Cell createCell(String content, boolean bold) {
        Cell cell = new Cell().add(new Paragraph(content));
        if (bold) {
            cell.setBold();
        }
        return cell;
    }

    private Cell createHeaderCell(String content) {
        return new Cell()
                .add(new Paragraph(content))
                .setBold()
                .setBackgroundColor(new DeviceRgb(33, 150, 243))
                .setFontColor(ColorConstants.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
    }

    private Cell createAmountCell(BigDecimal amount) {
        NumberFormat formatter = NumberFormat.getNumberInstance(Locale.US);
        formatter.setMinimumFractionDigits(2);
        formatter.setMaximumFractionDigits(2);

        return new Cell()
                .add(new Paragraph(formatter.format(amount)))
                .setTextAlignment(TextAlignment.RIGHT);
    }

    private String maskAccountNumber(String accountNumber) {
        if (accountNumber == null || accountNumber.length() < 4) {
            return "****";
        }
        return "****" + accountNumber.substring(accountNumber.length() - 4);
    }
}
