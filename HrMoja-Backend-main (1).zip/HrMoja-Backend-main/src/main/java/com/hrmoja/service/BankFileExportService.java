package com.hrmoja.service;

import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.entity.PayrollRecord;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.PayrollPeriodRepository;
import com.hrmoja.repository.PayrollRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Bank File Export Service
 * Generates bank upload files for salary disbursement
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BankFileExportService {

    private final PayrollPeriodRepository periodRepository;
    private final PayrollRecordRepository recordRepository;

    /**
     * Generate CSV bank file for salary transfers
     */
    public byte[] generateBankFile(Long periodId, String format) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        if (records.isEmpty()) {
            throw new IllegalStateException("No payroll records found for this period");
        }

        switch (format.toUpperCase()) {
            case "CSV":
                return generateCSVFile(period, records);
            case "SWIFT":
                return generateSWIFTFile(period, records);
            case "STANDARD":
            default:
                return generateStandardBankFile(period, records);
        }
    }

    /**
     * Generate standard CSV format
     */
    private byte[] generateCSVFile(PayrollPeriod period, List<PayrollRecord> records) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             PrintWriter writer = new PrintWriter(baos, false, StandardCharsets.UTF_8)) {

            // Header
            writer.println("Employee Number,Employee Name,Bank Name,Account Number,Amount,Narration");

            // Records
            for (PayrollRecord record : records) {
                if (record.getNetSalary().compareTo(BigDecimal.ZERO) > 0 && 
                    record.getAccountNumber() != null) {
                    
                    writer.printf("%s,%s,%s,%s,%.2f,Salary for %s%n",
                            escapeCSV(record.getEmployeeNumber()),
                            escapeCSV(record.getEmployeeName()),
                            escapeCSV(record.getBankName() != null ? record.getBankName() : ""),
                            record.getAccountNumber(),
                            record.getNetSalary(),
                            period.getPeriodName());
                }
            }

            writer.flush();
            log.info("CSV bank file generated for period: {}", period.getPeriodName());
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("Error generating CSV bank file: {}", e.getMessage());
            throw new RuntimeException("Failed to generate bank file", e);
        }
    }

    /**
     * Generate standard bank file format
     */
    private byte[] generateStandardBankFile(PayrollPeriod period, List<PayrollRecord> records) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             PrintWriter writer = new PrintWriter(baos, false, StandardCharsets.UTF_8)) {

            // Header record
            writer.println(createHeaderRecord(period, records));

            // Detail records
            int sequenceNumber = 1;
            for (PayrollRecord record : records) {
                if (record.getNetSalary().compareTo(BigDecimal.ZERO) > 0 && 
                    record.getAccountNumber() != null) {
                    writer.println(createDetailRecord(record, sequenceNumber++, period));
                }
            }

            // Trailer record
            writer.println(createTrailerRecord(records, sequenceNumber - 1));

            writer.flush();
            log.info("Standard bank file generated for period: {}", period.getPeriodName());
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("Error generating standard bank file: {}", e.getMessage());
            throw new RuntimeException("Failed to generate bank file", e);
        }
    }

    /**
     * Generate SWIFT/MT940 format (simplified)
     */
    private byte[] generateSWIFTFile(PayrollPeriod period, List<PayrollRecord> records) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             PrintWriter writer = new PrintWriter(baos, false, StandardCharsets.UTF_8)) {

            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyMMdd");
            String date = period.getPaymentDate().format(dateFormat);

            for (PayrollRecord record : records) {
                if (record.getNetSalary().compareTo(BigDecimal.ZERO) > 0 && 
                    record.getAccountNumber() != null) {
                    
                    // Simplified SWIFT format
                    writer.println(":20:SALARY" + date);
                    writer.println(":32A:" + date + "UGX" + record.getNetSalary());
                    writer.println(":50:" + record.getEmployeeName());
                    writer.println(":59:" + record.getAccountNumber());
                    writer.println(":70:Salary Payment " + period.getPeriodName());
                    writer.println("-");
                }
            }

            writer.flush();
            log.info("SWIFT bank file generated for period: {}", period.getPeriodName());
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("Error generating SWIFT bank file: {}", e.getMessage());
            throw new RuntimeException("Failed to generate bank file", e);
        }
    }

    private String createHeaderRecord(PayrollPeriod period, List<PayrollRecord> records) {
        BigDecimal totalAmount = records.stream()
                .map(PayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return String.format("H|%s|%s|%d|%.2f",
                period.getPeriodName(),
                period.getPaymentDate().format(DateTimeFormatter.ofPattern("yyyyMMdd")),
                records.size(),
                totalAmount);
    }

    private String createDetailRecord(PayrollRecord record, int sequenceNumber, PayrollPeriod period) {
        return String.format("D|%04d|%s|%s|%s|%.2f|SAL-%s",
                sequenceNumber,
                record.getEmployeeNumber(),
                record.getEmployeeName(),
                record.getAccountNumber(),
                record.getNetSalary(),
                period.getPeriodName());
    }

    private String createTrailerRecord(List<PayrollRecord> records, int totalRecords) {
        BigDecimal totalAmount = records.stream()
                .map(PayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return String.format("T|%d|%.2f", totalRecords, totalAmount);
    }

    private String escapeCSV(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /**
     * Generate summary report for bank upload
     */
    public String generateBankUploadSummary(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        BigDecimal totalAmount = records.stream()
                .map(PayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return String.format(
                "Bank Upload Summary\n" +
                "Period: %s\n" +
                "Payment Date: %s\n" +
                "Total Employees: %d\n" +
                "Total Amount: UGX %.2f\n",
                period.getPeriodName(),
                period.getPaymentDate(),
                records.size(),
                totalAmount
        );
    }
}
