package com.hrmoja.service;

import com.hrmoja.dto.report.DepartmentPayrollReport;
import com.hrmoja.dto.report.PayrollSummaryReport;
import com.hrmoja.dto.report.StatutoryReport;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.entity.PayrollRecord;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeeRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import com.hrmoja.repository.PayrollRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Payroll Reporting Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollReportService {

    private final PayrollPeriodRepository periodRepository;
    private final PayrollRecordRepository recordRepository;
    private final EmployeeRepository employeeRepository;

    /**
     * Generate comprehensive payroll summary report
     */
    @Transactional(readOnly = true)
    public PayrollSummaryReport generatePayrollSummary(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        if (records.isEmpty()) {
            return buildEmptyReport(period);
        }

        BigDecimal totalBasicSalary = records.stream()
                .map(PayrollRecord::getBasicSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalAllowances = records.stream()
                .map(PayrollRecord::getTotalAllowances)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalGrossSalary = records.stream()
                .map(PayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalDeductions = records.stream()
                .map(PayrollRecord::getTotalDeductions)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNetSalary = records.stream()
                .map(PayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPaye = records.stream()
                .map(PayrollRecord::getPayeTax)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNssfEmployee = records.stream()
                .map(PayrollRecord::getNssfEmployee)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNssfEmployer = records.stream()
                .map(PayrollRecord::getNssfEmployer)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalLst = records.stream()
                .map(PayrollRecord::getLstDeduction)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal avgGross = totalGrossSalary.divide(
                BigDecimal.valueOf(records.size()), 2, RoundingMode.HALF_UP);

        BigDecimal avgNet = totalNetSalary.divide(
                BigDecimal.valueOf(records.size()), 2, RoundingMode.HALF_UP);

        Long activeEmployees = employeeRepository.countByOrganizationIdAndIsActiveTrue(
                period.getOrganization().getId());

        return PayrollSummaryReport.builder()
                .periodName(period.getPeriodName())
                .startDate(period.getStartDate())
                .endDate(period.getEndDate())
                .paymentDate(period.getPaymentDate())
                .totalEmployees(period.getTotalEmployees())
                .activeEmployees(activeEmployees.intValue())
                .processedEmployees(records.size())
                .totalBasicSalary(totalBasicSalary)
                .totalAllowances(totalAllowances)
                .totalGrossSalary(totalGrossSalary)
                .totalDeductions(totalDeductions)
                .totalNetSalary(totalNetSalary)
                .totalPaye(totalPaye)
                .totalNssfEmployee(totalNssfEmployee)
                .totalNssfEmployer(totalNssfEmployer)
                .totalLst(totalLst)
                .averageGrossSalary(avgGross)
                .averageNetSalary(avgNet)
                .status(period.getStatus())
                .build();
    }

    /**
     * Generate department-wise payroll report
     */
    @Transactional(readOnly = true)
    public List<DepartmentPayrollReport> generateDepartmentReport(Long periodId) {
        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        if (records.isEmpty()) {
            return new ArrayList<>();
        }

        BigDecimal totalGross = records.stream()
                .map(PayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, List<PayrollRecord>> byDepartment = records.stream()
                .collect(Collectors.groupingBy(r -> 
                    r.getDepartmentName() != null ? r.getDepartmentName() : "Unassigned"));

        List<DepartmentPayrollReport> reports = new ArrayList<>();

        for (Map.Entry<String, List<PayrollRecord>> entry : byDepartment.entrySet()) {
            String deptName = entry.getKey();
            List<PayrollRecord> deptRecords = entry.getValue();

            BigDecimal deptGross = deptRecords.stream()
                    .map(PayrollRecord::getGrossSalary)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal deptNet = deptRecords.stream()
                    .map(PayrollRecord::getNetSalary)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal deptDeductions = deptRecords.stream()
                    .map(PayrollRecord::getTotalDeductions)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal avgSalary = deptGross.divide(
                    BigDecimal.valueOf(deptRecords.size()), 2, RoundingMode.HALF_UP);

            BigDecimal percentage = totalGross.compareTo(BigDecimal.ZERO) > 0
                    ? deptGross.divide(totalGross, 4, RoundingMode.HALF_UP)
                            .multiply(BigDecimal.valueOf(100))
                    : BigDecimal.ZERO;

            reports.add(DepartmentPayrollReport.builder()
                    .departmentName(deptName)
                    .employeeCount(deptRecords.size())
                    .totalGrossSalary(deptGross)
                    .totalNetSalary(deptNet)
                    .totalDeductions(deptDeductions)
                    .averageSalary(avgSalary)
                    .percentageOfTotal(percentage)
                    .build());
        }

        return reports.stream()
                .sorted((a, b) -> b.getTotalGrossSalary().compareTo(a.getTotalGrossSalary()))
                .collect(Collectors.toList());
    }

    /**
     * Generate PAYE statutory report
     */
    @Transactional(readOnly = true)
    public StatutoryReport generatePayeReport(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        BigDecimal totalGross = records.stream()
                .map(PayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalTaxableIncome = records.stream()
                .map(PayrollRecord::getTaxableIncome)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPaye = records.stream()
                .map(PayrollRecord::getPayeTax)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return StatutoryReport.builder()
                .periodName(period.getPeriodName())
                .startDate(period.getStartDate())
                .endDate(period.getEndDate())
                .reportType("PAYE")
                .totalEmployees(records.size())
                .totalGrossSalary(totalGross)
                .totalTaxableIncome(totalTaxableIncome)
                .totalPayeTax(totalPaye)
                .totalAmount(totalPaye)
                .build();
    }

    /**
     * Generate NSSF statutory report
     */
    @Transactional(readOnly = true)
    public StatutoryReport generateNssfReport(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        BigDecimal totalGross = records.stream()
                .map(PayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNssfEmployee = records.stream()
                .map(PayrollRecord::getNssfEmployee)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNssfEmployer = records.stream()
                .map(PayrollRecord::getNssfEmployer)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalNssf = totalNssfEmployee.add(totalNssfEmployer);

        return StatutoryReport.builder()
                .periodName(period.getPeriodName())
                .startDate(period.getStartDate())
                .endDate(period.getEndDate())
                .reportType("NSSF")
                .totalEmployees(records.size())
                .totalGrossSalary(totalGross)
                .totalNssfEmployee(totalNssfEmployee)
                .totalNssfEmployer(totalNssfEmployer)
                .totalNssfContribution(totalNssf)
                .totalAmount(totalNssf)
                .build();
    }

    /**
     * Generate LST statutory report
     */
    @Transactional(readOnly = true)
    public StatutoryReport generateLstReport(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<PayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        BigDecimal totalLst = records.stream()
                .map(PayrollRecord::getLstDeduction)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return StatutoryReport.builder()
                .periodName(period.getPeriodName())
                .startDate(period.getStartDate())
                .endDate(period.getEndDate())
                .reportType("LST")
                .totalEmployees(records.size())
                .totalLst(totalLst)
                .totalAmount(totalLst)
                .build();
    }

    private PayrollSummaryReport buildEmptyReport(PayrollPeriod period) {
        return PayrollSummaryReport.builder()
                .periodName(period.getPeriodName())
                .startDate(period.getStartDate())
                .endDate(period.getEndDate())
                .paymentDate(period.getPaymentDate())
                .totalEmployees(0)
                .activeEmployees(0)
                .processedEmployees(0)
                .totalBasicSalary(BigDecimal.ZERO)
                .totalAllowances(BigDecimal.ZERO)
                .totalGrossSalary(BigDecimal.ZERO)
                .totalDeductions(BigDecimal.ZERO)
                .totalNetSalary(BigDecimal.ZERO)
                .totalPaye(BigDecimal.ZERO)
                .totalNssfEmployee(BigDecimal.ZERO)
                .totalNssfEmployer(BigDecimal.ZERO)
                .totalLst(BigDecimal.ZERO)
                .averageGrossSalary(BigDecimal.ZERO)
                .averageNetSalary(BigDecimal.ZERO)
                .status(period.getStatus())
                .build();
    }
}
