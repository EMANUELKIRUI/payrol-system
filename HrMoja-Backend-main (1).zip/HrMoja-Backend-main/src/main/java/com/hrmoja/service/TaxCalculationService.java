package com.hrmoja.service;

import com.hrmoja.repository.PayrollTaxBracketRepository;
import com.hrmoja.repository.PayrollTaxConfigurationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

/**
 * Tax Calculation Service - Progressive PAYE calculation for Uganda/Kenya
 */
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class TaxCalculationService {

    private final PayrollTaxConfigurationRepository taxConfigRepository;
    private final PayrollTaxBracketRepository taxBracketRepository;

    /**
     * Calculate PAYE tax using progressive brackets
     * 
     * @param taxableIncome The taxable income after NSSF and LST deductions
     * @param organizationId Organization ID
     * @param countryCode Country code (UG, KE, etc.)
     * @return PAYE tax amount
     */
    public BigDecimal calculatePAYE(BigDecimal taxableIncome, Long organizationId, String countryCode) {
        if (taxableIncome == null || taxableIncome.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        // Get active tax configuration for current year
        int currentYear = LocalDate.now().getYear();
        var taxConfigs = taxConfigRepository.findActiveConfigurations(organizationId, countryCode, currentYear);
        
        if (taxConfigs == null || taxConfigs.isEmpty()) {
            log.warn("No active tax configuration found for organization {} and country {}", organizationId, countryCode);
            return BigDecimal.ZERO;
        }
        
        var taxConfig = taxConfigs.get(0); // Get the most recent one (ordered by effectiveFrom DESC)

        // Get tax brackets ordered by min_income
        var brackets = taxBracketRepository.findByTaxConfigurationIdOrderByBracketNumber(taxConfig.getId());
        
        if (brackets.isEmpty()) {
            log.warn("No tax brackets found for tax configuration {}", taxConfig.getId());
            return BigDecimal.ZERO;
        }

        return calculateProgressiveTax(taxableIncome, brackets);
    }

    /**
     * Calculate tax using progressive brackets
     * Uganda Example:
     * - 0 - 235,000: 0%
     * - 235,001 - 335,000: 10% on excess over 235,000
     * - 335,001 - 410,000: 10,000 + 20% on excess over 335,000
     * - etc.
     */
    private BigDecimal calculateProgressiveTax(BigDecimal taxableIncome, List<?> brackets) {
        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal remainingIncome = taxableIncome;

        for (Object bracketObj : brackets) {
            // Use reflection to get bracket properties (supports both old and new bracket entities)
            BigDecimal minIncome = getBracketField(bracketObj, "minIncome");
            BigDecimal maxIncome = getBracketField(bracketObj, "maxIncome");
            BigDecimal taxRate = getBracketField(bracketObj, "taxRate");
            BigDecimal fixedAmount = getBracketField(bracketObj, "fixedAmount");

            if (taxableIncome.compareTo(minIncome) <= 0) {
                // Income doesn't reach this bracket
                break;
            }

            // Determine the upper bound for this bracket
            BigDecimal upperBound = (maxIncome != null) ? maxIncome : taxableIncome;

            if (taxableIncome.compareTo(upperBound) >= 0) {
                // Income exceeds this bracket - tax the full bracket range
                BigDecimal taxableInBracket = upperBound.subtract(minIncome).add(BigDecimal.ONE);
                BigDecimal bracketTax = taxableInBracket.multiply(taxRate).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
                
                if (fixedAmount != null && fixedAmount.compareTo(BigDecimal.ZERO) > 0) {
                    totalTax = fixedAmount.add(bracketTax);
                } else {
                    totalTax = totalTax.add(bracketTax);
                }
            } else {
                // Income falls within this bracket - calculate partial tax
                BigDecimal taxableInBracket = taxableIncome.subtract(minIncome);
                BigDecimal bracketTax = taxableInBracket.multiply(taxRate).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
                
                if (fixedAmount != null && fixedAmount.compareTo(BigDecimal.ZERO) > 0) {
                    totalTax = fixedAmount.add(bracketTax);
                } else {
                    totalTax = totalTax.add(bracketTax);
                }
                break; // We've calculated all tax for this income
            }
        }

        return totalTax.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Get bracket field using reflection (supports different bracket entity structures)
     */
    private BigDecimal getBracketField(Object bracket, String fieldName) {
        try {
            var field = bracket.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(bracket);
            return (value != null) ? (BigDecimal) value : BigDecimal.ZERO;
        } catch (Exception e) {
            log.warn("Failed to get field {} from bracket: {}", fieldName, e.getMessage());
            return BigDecimal.ZERO;
        }
    }

    /**
     * Calculate NSSF employee contribution (5% in Uganda, 6% in Kenya)
     */
    public BigDecimal calculateNSSFEmployee(BigDecimal grossSalary, String countryCode) {
        if (grossSalary == null || grossSalary.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        // Uganda: 5%, no ceiling
        if ("UGA".equals(countryCode)) {
            return grossSalary.multiply(BigDecimal.valueOf(0.05))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        // Kenya: 6%, with ceiling (will implement tier structure later)
        if ("KEN".equals(countryCode)) {
            BigDecimal contribution = grossSalary.multiply(BigDecimal.valueOf(0.06))
                    .setScale(2, RoundingMode.HALF_UP);
            // Apply ceiling of 4,320 KES per month
            BigDecimal ceiling = BigDecimal.valueOf(4320);
            return contribution.min(ceiling);
        }

        return BigDecimal.ZERO;
    }

    /**
     * Calculate NSSF employer contribution (10% in Uganda, 6% in Kenya)
     */
    public BigDecimal calculateNSSFEmployer(BigDecimal grossSalary, String countryCode) {
        if (grossSalary == null || grossSalary.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }

        // Uganda: 10%, no ceiling
        if ("UGA".equals(countryCode)) {
            return grossSalary.multiply(BigDecimal.valueOf(0.10))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        // Kenya: 6%, with ceiling
        if ("KEN".equals(countryCode)) {
            BigDecimal contribution = grossSalary.multiply(BigDecimal.valueOf(0.06))
                    .setScale(2, RoundingMode.HALF_UP);
            BigDecimal ceiling = BigDecimal.valueOf(4320);
            return contribution.min(ceiling);
        }

        return BigDecimal.ZERO;
    }

    /**
     * Calculate Local Service Tax (Uganda only)
     * Annual: 40,000 UGX, Monthly: 3,333 UGX
     */
    public BigDecimal calculateLST(String countryCode) {
        if ("UGA".equals(countryCode)) {
            return BigDecimal.valueOf(3333).setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    /**
     * Calculate taxable income
     * Taxable Income = Gross Salary - NSSF Employee - LST
     */
    public BigDecimal calculateTaxableIncome(BigDecimal grossSalary, BigDecimal nssfEmployee, BigDecimal lst) {
        BigDecimal taxableIncome = grossSalary;
        
        if (nssfEmployee != null) {
            taxableIncome = taxableIncome.subtract(nssfEmployee);
        }
        
        if (lst != null) {
            taxableIncome = taxableIncome.subtract(lst);
        }
        
        return taxableIncome.max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
    }
}
