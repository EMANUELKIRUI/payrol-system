package com.hrmoja.service;

import com.hrmoja.dto.organization.OrganizationRegistrationRequest;
import com.hrmoja.dto.organization.OrganizationRegistrationResponse;
import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

/**
 * Organization Registration Service
 * Handles multi-tenant organization onboarding
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationRegistrationService {

    private final OrganizationRepository organizationRepository;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final CountryRepository countryRepository;
    private final BranchRepository branchRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Register a new organization with super admin user
     * This is the main onboarding flow for the SaaS platform
     */
    @Transactional
    public OrganizationRegistrationResponse registerOrganization(OrganizationRegistrationRequest request) {
        log.info("Starting organization registration for: {}", request.getOrganizationName());

        // Validate uniqueness
        validateRegistrationRequest(request);

        // Get country
        Country country = countryRepository.findById(request.getCountryId())
                .orElseThrow(() -> new ResourceNotFoundException("Country not found"));

        // 1. Create Organization
        Organization organization = createOrganization(request, country);
        log.info("Organization created with ID: {}", organization.getId());

        // 2. Create Headquarters Branch
        Branch branch = createHeadquartersBranch(organization, request, country);
        log.info("Headquarters branch created with ID: {}", branch.getId());

        // 3. Create Super Admin User
        User adminUser = createSuperAdminUser(request, organization);
        log.info("Super admin user created with ID: {}", adminUser.getId());

        // 4. Build response
        return OrganizationRegistrationResponse.builder()
                .organizationId(organization.getId())
                .organizationName(organization.getName())
                .adminUserId(adminUser.getId())
                .adminUsername(adminUser.getUsername())
                .adminEmail(adminUser.getEmail())
                .branchId(branch.getId())
                .branchName(branch.getName())
                .message("Organization registered successfully. Please check your email for verification.")
                .emailVerificationRequired(true)
                .build();
    }

    private void validateRegistrationRequest(OrganizationRegistrationRequest request) {
        // Check if username exists
        if (userRepository.existsByUsername(request.getAdminUsername())) {
            throw new IllegalArgumentException("Username already exists: " + request.getAdminUsername());
        }

        // Check if email exists
        if (userRepository.existsByEmail(request.getAdminEmail())) {
            throw new IllegalArgumentException("Email already registered: " + request.getAdminEmail());
        }

        // Check if registration number exists (optional, can be null)
        if (request.getRegistrationNumber() != null && 
            organizationRepository.existsByRegistrationNumber(request.getRegistrationNumber())) {
            throw new IllegalArgumentException("Organization registration number already exists");
        }
    }

    private Organization createOrganization(OrganizationRegistrationRequest request, Country country) {
        Organization organization = Organization.builder()
                .name(request.getOrganizationName())
                .legalName(request.getLegalName() != null ? request.getLegalName() : request.getOrganizationName())
                .registrationNumber(request.getRegistrationNumber())
                .taxIdentificationNumber(request.getTaxIdentificationNumber())
                .country(country)
                .addressLine1(request.getAddressLine1())
                .addressLine2(request.getAddressLine2())
                .city(request.getCity())
                .stateProvince(request.getStateProvince())
                .postalCode(request.getPostalCode())
                .phoneNumber(request.getPhoneNumber())
                .email(request.getOrganizationEmail())
                .website(request.getWebsite())
                .isActive(true)
                .build();

        return organizationRepository.save(organization);
    }

    private Branch createHeadquartersBranch(Organization organization, 
                                           OrganizationRegistrationRequest request, 
                                           Country country) {
        Branch branch = Branch.builder()
                .organization(organization)
                .name(request.getBranchName() != null ? request.getBranchName() : "Headquarters")
                .code(generateBranchCode(organization))
                .country(country)
                .addressLine1(request.getAddressLine1())
                .addressLine2(request.getAddressLine2())
                .city(request.getBranchCity() != null ? request.getBranchCity() : request.getCity())
                .stateProvince(request.getStateProvince())
                .postalCode(request.getPostalCode())
                .phoneNumber(request.getPhoneNumber())
                .email(request.getOrganizationEmail())
                .isHeadquarters(true)
                .isActive(true)
                .build();

        return branchRepository.save(branch);
    }

    private User createSuperAdminUser(OrganizationRegistrationRequest request, Organization organization) {
        // Get or create ADMIN role
        Role adminRole = roleRepository.findByCode("ADMIN")
                .orElseThrow(() -> new ResourceNotFoundException("Admin role not found in system"));

        // Create user
        User user = User.builder()
                .username(request.getAdminUsername())
                .email(request.getAdminEmail())
                .passwordHash(passwordEncoder.encode(request.getAdminPassword()))
                .firstName(request.getAdminFirstName())
                .lastName(request.getAdminLastName())
                .phoneNumber(request.getAdminPhoneNumber())
                .organizationId(organization.getId())
                .isActive(true)
                .isLocked(false)
                .isEmailVerified(false)
                .failedLoginAttempts(0)
                .mustChangePassword(false)
                .build();

        // Assign admin role
        Set<Role> roles = new HashSet<>();
        roles.add(adminRole);
        user.setRoles(roles);

        return userRepository.save(user);
    }

    private String generateBranchCode(Organization organization) {
        // Generate branch code based on organization name
        String orgPrefix = organization.getName()
                .replaceAll("[^A-Za-z0-9]", "")
                .toUpperCase()
                .substring(0, Math.min(3, organization.getName().length()));
        
        return orgPrefix + "-HQ";
    }

    /**
     * Get organization details by ID
     */
    @Transactional(readOnly = true)
    public Organization getOrganizationById(Long organizationId) {
        return organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found with id: " + organizationId));
    }
}
