package com.hrmoja.service;

import com.hrmoja.dto.user.PasswordChangeRequest;
import com.hrmoja.dto.user.UserCreateRequest;
import com.hrmoja.dto.user.UserDto;
import com.hrmoja.dto.user.UserUpdateRequest;
import com.hrmoja.entity.Organization;
import com.hrmoja.entity.Role;
import com.hrmoja.entity.User;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.exception.ValidationException;
import com.hrmoja.repository.OrganizationRepository;
import com.hrmoja.repository.RoleRepository;
import com.hrmoja.repository.UserRepository;
import com.hrmoja.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * User Management Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserManagementService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final OrganizationRepository organizationRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<UserDto> getAllUsers() {
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        
        // Platform admins (no org) see all users, org admins see only their org's users
        if (currentUserOrgId == null) {
            return userRepository.findAll().stream()
                    .map(this::convertToDto)
                    .collect(Collectors.toList());
        }
        
        return userRepository.findAll().stream()
                .filter(user -> currentUserOrgId.equals(user.getOrganizationId()))
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<UserDto> getUsersPaginated(Pageable pageable) {
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        
        // Platform admins (no org) see all users, org admins see only their org's users
        if (currentUserOrgId == null) {
            return userRepository.findAll(pageable).map(this::convertToDto);
        }
        
        List<UserDto> filteredUsers = userRepository.findAll().stream()
                .filter(user -> currentUserOrgId.equals(user.getOrganizationId()))
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), filteredUsers.size());
        
        return new PageImpl<>(filteredUsers.subList(start, end), pageable, filteredUsers.size());
    }

    @Transactional(readOnly = true)
    public UserDto getUserById(Long id) {
        User user = userRepository.findByIdWithRoles(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return convertToDto(user);
    }

    @Transactional(readOnly = true)
    public UserDto getUserByUsername(String username) {
        User user = userRepository.findByUsernameWithRolesAndPermissions(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username: " + username));
        return convertToDto(user);
    }

    @Transactional(readOnly = true)
    public List<UserDto> getUsersByOrganization(Long organizationId) {
        return userRepository.findAll().stream()
                .filter(user -> user.getOrganizationId() != null && user.getOrganizationId().equals(organizationId))
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public boolean usernameExists(String username) {
        return userRepository.existsByUsername(username);
    }

    @Transactional
    public UserDto createUser(UserCreateRequest request) {
        // Validate username and email uniqueness
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new ValidationException("Username already exists");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ValidationException("Email already exists");
        }

        // Get roles
        Set<Role> roles = new HashSet<>();
        if (request.getRoleIds() != null && !request.getRoleIds().isEmpty()) {
            roles = request.getRoleIds().stream()
                    .map(roleId -> roleRepository.findById(roleId)
                            .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + roleId)))
                    .collect(Collectors.toSet());
        }

        // Validate organization if provided
        if (request.getOrganizationId() != null) {
            organizationRepository.findById(request.getOrganizationId())
                    .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));
        }

        // Build user
        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phoneNumber(request.getPhoneNumber())
                .organizationId(request.getOrganizationId())
                .employeeId(request.getEmployeeId())
                .mustChangePassword(request.isMustChangePassword())
                .isActive(true)
                .isLocked(false)
                .isEmailVerified(false)
                .failedLoginAttempts(0)
                .roles(roles)
                .build();

        user = userRepository.save(user);
        log.info("User created: {}", user.getUsername());

        return convertToDto(user);
    }

    @Transactional
    public UserDto updateUser(Long id, UserUpdateRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        // Check organization access - org admins can only update users in their organization
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        if (currentUserOrgId != null && !currentUserOrgId.equals(user.getOrganizationId())) {
            throw new ValidationException("You can only update users within your organization");
        }

        // Update basic fields
        if (request.getEmail() != null && !request.getEmail().equals(user.getEmail())) {
            if (userRepository.existsByEmail(request.getEmail())) {
                throw new ValidationException("Email already exists");
            }
            user.setEmail(request.getEmail());
        }

        if (request.getFirstName() != null) {
            user.setFirstName(request.getFirstName());
        }

        if (request.getLastName() != null) {
            user.setLastName(request.getLastName());
        }

        if (request.getPhoneNumber() != null) {
            user.setPhoneNumber(request.getPhoneNumber());
        }

        if (request.getOrganizationId() != null) {
            organizationRepository.findById(request.getOrganizationId())
                    .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));
            user.setOrganizationId(request.getOrganizationId());
        }

        if (request.getEmployeeId() != null) {
            user.setEmployeeId(request.getEmployeeId());
        }

        if (request.getIsActive() != null) {
            user.setActive(request.getIsActive());
        }

        if (request.getIsLocked() != null) {
            user.setLocked(request.getIsLocked());
        }

        if (request.getMustChangePassword() != null) {
            user.setMustChangePassword(request.getMustChangePassword());
        }

        // Update roles if provided
        if (request.getRoleIds() != null) {
            // Prevent users from changing their own roles
            SecurityUtils.getCurrentUserId().ifPresent(currentUserId -> {
                if (currentUserId.equals(id)) {
                    throw new ValidationException("You cannot change your own roles");
                }
            });
            
            Set<Role> roles = request.getRoleIds().stream()
                    .map(roleId -> roleRepository.findById(roleId)
                            .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + roleId)))
                    .collect(Collectors.toSet());
            user.setRoles(roles);
        }

        user = userRepository.save(user);
        log.info("User updated: {}", user.getUsername());

        return convertToDto(user);
    }

    @Transactional
    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        
        // Check organization access
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        if (currentUserOrgId != null && !currentUserOrgId.equals(user.getOrganizationId())) {
            throw new ValidationException("You can only deactivate users within your organization");
        }
        
        user.setActive(false);
        userRepository.save(user);
        log.info("User deactivated: {}", user.getUsername());
    }

    @Transactional
    public void activateUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        
        // Check organization access
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        if (currentUserOrgId != null && !currentUserOrgId.equals(user.getOrganizationId())) {
            throw new ValidationException("You can only activate users within your organization");
        }
        
        user.setActive(true);
        userRepository.save(user);
        log.info("User activated: {}", user.getUsername());
    }

    @Transactional
    public void changePassword(Long userId, PasswordChangeRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Validate current password
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
            throw new ValidationException("Current password is incorrect");
        }

        // Validate new password matches confirmation
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new ValidationException("New password and confirmation do not match");
        }

        // Update password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        user.setMustChangePassword(false);
        userRepository.save(user);

        log.info("Password changed for user: {}", user.getUsername());
    }

    @Transactional
    public void resetPassword(Long userId, String newPassword) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setPasswordHash(passwordEncoder.encode(newPassword));
        user.setMustChangePassword(true);
        userRepository.save(user);

        log.info("Password reset for user: {}", user.getUsername());
    }

    @Transactional
    public void lockUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // Check organization access
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        if (currentUserOrgId != null && !currentUserOrgId.equals(user.getOrganizationId())) {
            throw new ValidationException("You can only lock users within your organization");
        }
        
        user.setLocked(true);
        user.setLockedUntil(LocalDateTime.now().plusDays(30));
        userRepository.save(user);

        log.info("User locked: {}", user.getUsername());
    }

    @Transactional
    public void unlockUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // Check organization access
        Long currentUserOrgId = SecurityUtils.getCurrentUserOrganizationId();
        if (currentUserOrgId != null && !currentUserOrgId.equals(user.getOrganizationId())) {
            throw new ValidationException("You can only unlock users within your organization");
        }
        
        user.setLocked(false);
        user.setLockedUntil(null);
        user.setFailedLoginAttempts(0);
        userRepository.save(user);

        log.info("User unlocked: {}", user.getUsername());
    }

    private UserDto convertToDto(User user) {
        List<String> roleNames = user.getRoles().stream()
                .map(Role::getName)
                .collect(Collectors.toList());

        List<Long> roleIds = user.getRoles().stream()
                .map(Role::getId)
                .collect(Collectors.toList());

        List<String> permissions = user.getRoles().stream()
                .flatMap(role -> role.getPermissions().stream())
                .map(permission -> permission.getCode())  // Use CODE not NAME for consistency with security
                .distinct()
                .collect(Collectors.toList());

        String organizationName = null;
        if (user.getOrganizationId() != null) {
            organizationName = organizationRepository.findById(user.getOrganizationId())
                    .map(Organization::getName)
                    .orElse(null);
        }

        return UserDto.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .fullName(user.getFullName())
                .phoneNumber(user.getPhoneNumber())
                .isActive(user.isActive())
                .isLocked(user.isLocked())
                .isEmailVerified(user.isEmailVerified())
                .mustChangePassword(user.isMustChangePassword())
                .employeeId(user.getEmployeeId())
                .organizationId(user.getOrganizationId())
                .organizationName(organizationName)
                .lastLoginAt(user.getLastLoginAt())
                .lastLoginIp(user.getLastLoginIp())
                .failedLoginAttempts(user.getFailedLoginAttempts())
                .roles(roleNames)
                .roleIds(roleIds)
                .permissions(permissions)
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
