package com.hrmoja.security;

import lombok.extern.slf4j.Slf4j;

/**
 * Organization Context for Multi-Tenancy
 * Stores the current organization ID in ThreadLocal for data isolation
 */
@Slf4j
public class OrganizationContext {

    private static final ThreadLocal<Long> currentOrganizationId = new ThreadLocal<>();

    public static void setCurrentOrganizationId(Long organizationId) {
        log.debug("Setting organization context: {}", organizationId);
        currentOrganizationId.set(organizationId);
    }

    public static Long getCurrentOrganizationId() {
        return currentOrganizationId.get();
    }

    public static void clear() {
        log.debug("Clearing organization context");
        currentOrganizationId.remove();
    }

    public static boolean hasOrganizationContext() {
        return currentOrganizationId.get() != null;
    }
}
