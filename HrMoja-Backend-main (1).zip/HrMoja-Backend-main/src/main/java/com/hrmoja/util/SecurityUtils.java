package com.hrmoja.util;

import com.hrmoja.security.UserDetailsImpl;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

/**
 * Security Utility Class
 * Provides helper methods for security operations
 */
public class SecurityUtils {

    private SecurityUtils() {
        // Private constructor to prevent instantiation
    }

    /**
     * Get the currently authenticated user's ID
     */
    public static Optional<Long> getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            return Optional.of(userDetails.getId());
        }
        
        return Optional.empty();
    }

    /**
     * Get the currently authenticated username
     */
    public static Optional<String> getCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            return Optional.of(userDetails.getUsername());
        }
        
        return Optional.empty();
    }

    /**
     * Get the currently authenticated user details
     */
    public static Optional<UserDetailsImpl> getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication != null && authentication.getPrincipal() instanceof UserDetailsImpl) {
            return Optional.of((UserDetailsImpl) authentication.getPrincipal());
        }
        
        return Optional.empty();
    }

    /**
     * Check if the current user has a specific permission
     */
    public static boolean hasPermission(String permission) {
        return getCurrentUser()
                .map(user -> user.getAuthorities().stream()
                        .anyMatch(auth -> auth.getAuthority().equals(permission)))
                .orElse(false);
    }

    /**
     * Check if the current user has a specific role
     */
    public static boolean hasRole(String role) {
        String roleWithPrefix = role.startsWith("ROLE_") ? role : "ROLE_" + role;
        return getCurrentUser()
                .map(user -> user.getAuthorities().stream()
                        .anyMatch(auth -> auth.getAuthority().equals(roleWithPrefix)))
                .orElse(false);
    }

    /**
     * Check if user is authenticated
     */
    public static boolean isAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated();
    }

    /**
     * Get the currently authenticated user's organization ID
     * Platform admins (SUPER_ADMIN, PLATFORM_ADMIN) have no organization (returns null)
     * Organization users/admins return their organizationId
     */
    public static Long getCurrentUserOrganizationId() {
        return getCurrentUser()
                .map(UserDetailsImpl::getOrganizationId)
                .orElse(null);
    }
}
