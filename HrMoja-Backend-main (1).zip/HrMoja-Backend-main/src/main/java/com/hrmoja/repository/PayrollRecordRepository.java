package com.hrmoja.repository;

import com.hrmoja.entity.PayrollRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollRecordRepository extends JpaRepository<PayrollRecord, Long> {
    
    List<PayrollRecord> findByPayrollPeriodId(Long periodId);
    
    Optional<PayrollRecord> findByPayrollPeriodIdAndEmployeeId(Long periodId, Long employeeId);
    
    List<PayrollRecord> findByEmployeeId(Long employeeId);
    
    @Query("SELECT COUNT(p) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    Long countByPayrollPeriodId(@Param("periodId") Long periodId);
    
    @Query("SELECT SUM(p.grossSalary) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    BigDecimal sumGrossSalaryByPeriod(@Param("periodId") Long periodId);
    
    @Query("SELECT SUM(p.netSalary) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    BigDecimal sumNetSalaryByPeriod(@Param("periodId") Long periodId);
    
    @Query("SELECT SUM(p.payeTax) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    BigDecimal sumPayeTaxByPeriod(@Param("periodId") Long periodId);
    
    @Query("SELECT SUM(p.nssfEmployee) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    BigDecimal sumNssfEmployeeByPeriod(@Param("periodId") Long periodId);
    
    @Query("SELECT SUM(p.nssfEmployer) FROM PayrollRecord p WHERE p.payrollPeriod.id = :periodId")
    BigDecimal sumNssfEmployerByPeriod(@Param("periodId") Long periodId);
    
    boolean existsByPayrollPeriodIdAndEmployeeId(Long periodId, Long employeeId);
}
