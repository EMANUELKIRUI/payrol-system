package com.hrmoja.repository;

import com.hrmoja.entity.PayrollJob;
import com.hrmoja.entity.PayrollJob.JobStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollJobRepository extends JpaRepository<PayrollJob, Long> {
    
    /**
     * Find the latest job for a payroll period
     */
    Optional<PayrollJob> findFirstByPayrollPeriodIdOrderByCreatedAtDesc(Long payrollPeriodId);
    
    /**
     * Find all jobs for a payroll period
     */
    List<PayrollJob> findByPayrollPeriodIdOrderByCreatedAtDesc(Long payrollPeriodId);
    
    /**
     * Find jobs by status
     */
    List<PayrollJob> findByStatus(JobStatus status);
    
    /**
     * Check if there's an active job for a period
     */
    @Query("SELECT CASE WHEN COUNT(j) > 0 THEN true ELSE false END FROM PayrollJob j " +
           "WHERE j.payrollPeriodId = :periodId " +
           "AND j.status IN ('QUEUED', 'PROCESSING')")
    boolean hasActiveJob(@Param("periodId") Long payrollPeriodId);
}
