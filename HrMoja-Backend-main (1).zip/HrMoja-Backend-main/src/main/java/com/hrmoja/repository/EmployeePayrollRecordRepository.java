package com.hrmoja.repository;

import com.hrmoja.entity.EmployeePayrollRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeePayrollRecordRepository extends JpaRepository<EmployeePayrollRecord, Long> {
    
    List<EmployeePayrollRecord> findByPayrollPeriodId(Long payrollPeriodId);
    
    Optional<EmployeePayrollRecord> findByPayrollPeriodIdAndEmployeeId(Long payrollPeriodId, Long employeeId);
    
    List<EmployeePayrollRecord> findByEmployeeId(Long employeeId);
    
    @Query("SELECT e FROM EmployeePayrollRecord e WHERE e.payrollPeriod.id = :periodId AND e.status = :status")
    List<EmployeePayrollRecord> findByPayrollPeriodIdAndStatus(@Param("periodId") Long periodId, @Param("status") String status);
    
    @Query("SELECT COUNT(e) FROM EmployeePayrollRecord e WHERE e.payrollPeriod.id = :periodId AND e.isPaid = true")
    Long countPaidRecordsByPeriod(@Param("periodId") Long periodId);
}
