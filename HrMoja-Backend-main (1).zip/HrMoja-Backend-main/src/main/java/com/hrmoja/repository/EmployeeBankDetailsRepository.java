package com.hrmoja.repository;

import com.hrmoja.entity.EmployeeBankDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeBankDetailsRepository extends JpaRepository<EmployeeBankDetails, Long> {

    @Query("SELECT b FROM EmployeeBankDetails b WHERE b.employee.id = :employeeId AND b.primary = true AND b.active = true")
    Optional<EmployeeBankDetails> findPrimaryByEmployeeId(@Param("employeeId") Long employeeId);

    @Query("SELECT b FROM EmployeeBankDetails b WHERE b.employee.id = :employeeId AND b.active = true ORDER BY b.primary DESC, b.createdAt DESC")
    List<EmployeeBankDetails> findAllByEmployeeId(@Param("employeeId") Long employeeId);

    @Query("SELECT b FROM EmployeeBankDetails b WHERE b.employee.id = :employeeId AND b.active = true")
    List<EmployeeBankDetails> findActiveByEmployeeId(@Param("employeeId") Long employeeId);
}
