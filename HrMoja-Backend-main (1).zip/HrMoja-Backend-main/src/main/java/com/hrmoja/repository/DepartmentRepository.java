package com.hrmoja.repository;

import com.hrmoja.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Department Repository
 */
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    @Query("SELECT d FROM Department d LEFT JOIN FETCH d.organization LEFT JOIN FETCH d.branch WHERE d.id = :id")
    Optional<Department> findByIdWithDetails(@Param("id") Long id);

    List<Department> findByOrganizationId(Long organizationId);

    List<Department> findByParentDepartmentId(Long parentId);

    List<Department> findByOrganizationIdAndIsActiveTrue(Long organizationId);

    @Query("SELECT d FROM Department d WHERE d.organization.id = :orgId AND d.parentDepartment IS NULL")
    List<Department> findRootDepartments(@Param("orgId") Long organizationId);

    boolean existsByOrganizationIdAndCode(Long organizationId, String code);
}
