package com.hrmoja.repository;

import com.hrmoja.entity.Organization;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Organization Repository
 */
@Repository
public interface OrganizationRepository extends JpaRepository<Organization, Long> {

    @Query("SELECT o FROM Organization o LEFT JOIN FETCH o.country WHERE o.id = :id")
    Optional<Organization> findByIdWithCountry(@Param("id") Long id);

    List<Organization> findByIsActiveTrue();

    List<Organization> findByCountryId(Long countryId);

    boolean existsByRegistrationNumber(String registrationNumber);
}
