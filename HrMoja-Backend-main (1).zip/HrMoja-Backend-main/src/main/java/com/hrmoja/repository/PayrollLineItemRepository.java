package com.hrmoja.repository;

import com.hrmoja.entity.PayrollLineItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PayrollLineItemRepository extends JpaRepository<PayrollLineItem, Long> {
    
    List<PayrollLineItem> findByEmployeePayrollRecordId(Long employeePayrollRecordId);
    
    List<PayrollLineItem> findByEmployeePayrollRecordIdAndComponentCategory(Long employeePayrollRecordId, String componentCategory);
    
    void deleteByEmployeePayrollRecordId(Long employeePayrollRecordId);
}
