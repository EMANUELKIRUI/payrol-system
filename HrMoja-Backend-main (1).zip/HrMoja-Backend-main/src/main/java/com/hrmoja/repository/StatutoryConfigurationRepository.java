package com.hrmoja.repository;

import com.hrmoja.entity.StatutoryConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface StatutoryConfigurationRepository extends JpaRepository<StatutoryConfiguration, Long> {
    
    List<StatutoryConfiguration> findByCountryId(Long countryId);
    
    List<StatutoryConfiguration> findByCountryIdAndStatutoryType(Long countryId, String type);
    
    @Query("SELECT s FROM StatutoryConfiguration s WHERE s.country.id = :countryId AND s.code = :code AND " +
           "s.effectiveFrom <= :date AND (s.effectiveTo IS NULL OR s.effectiveTo >= :date) AND s.isActive = true")
    Optional<StatutoryConfiguration> findActiveConfigurationForDate(@Param("countryId") Long countryId,
                                                                     @Param("code") String code,
                                                                     @Param("date") LocalDate date);
    
    List<StatutoryConfiguration> findByCountryIdAndIsActiveTrue(Long countryId);
}
