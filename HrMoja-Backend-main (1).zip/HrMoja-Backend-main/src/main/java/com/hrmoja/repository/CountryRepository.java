package com.hrmoja.repository;

import com.hrmoja.entity.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Country Repository
 */
@Repository
public interface CountryRepository extends JpaRepository<Country, Long> {

    Optional<Country> findByCode(String code);

    Optional<Country> findByIsoCode(String isoCode);

    List<Country> findByIsActiveTrue();

    boolean existsByCode(String code);
}
