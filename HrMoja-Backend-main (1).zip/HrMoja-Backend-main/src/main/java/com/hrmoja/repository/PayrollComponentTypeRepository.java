package com.hrmoja.repository;

import com.hrmoja.entity.PayrollComponentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollComponentTypeRepository extends JpaRepository<PayrollComponentType, Long> {
    Optional<PayrollComponentType> findByCode(String code);
    List<PayrollComponentType> findByCalculationCategory(String category);
    List<PayrollComponentType> findByIsActiveTrue();
    boolean existsByCode(String code);
}
