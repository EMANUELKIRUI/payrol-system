package com.hrmoja.repository;

import com.hrmoja.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Employee Repository
 */
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e FROM Employee e LEFT JOIN FETCH e.organization LEFT JOIN FETCH e.branch " +
           "LEFT JOIN FETCH e.department LEFT JOIN FETCH e.jobTitle WHERE e.id = :id")
    Optional<Employee> findByIdWithDetails(@Param("id") Long id);

    Optional<Employee> findByEmployeeNumber(String employeeNumber);

    List<Employee> findByOrganizationId(Long organizationId);

    Page<Employee> findByOrganizationId(Long organizationId, Pageable pageable);

    List<Employee> findByOrganizationIdAndIsActiveTrue(Long organizationId);

    List<Employee> findByDepartmentId(Long departmentId);

    List<Employee> findByReportsToEmployeeId(Long managerId);

    @Query("SELECT e FROM Employee e WHERE e.organization.id = :orgId AND " +
           "(LOWER(e.firstName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(e.lastName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(e.workEmail) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(e.employeeNumber) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Employee> searchEmployees(@Param("orgId") Long organizationId, 
                                   @Param("search") String searchTerm, 
                                   Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.organization.id = :orgId " +
           "AND (:search IS NULL OR :search = '' OR LOWER(e.firstName) LIKE LOWER(CONCAT('%', :search, '%')) " +
           "OR LOWER(e.lastName) LIKE LOWER(CONCAT('%', :search, '%')) " +
           "OR LOWER(COALESCE(e.workEmail, '')) LIKE LOWER(CONCAT('%', :search, '%')) " +
           "OR LOWER(CAST(e.employeeNumber AS string)) LIKE LOWER(CONCAT('%', :search, '%'))) " +
           "AND (:departmentId IS NULL OR e.department.id = :departmentId) " +
           "AND (:branchId IS NULL OR e.branch.id = :branchId) " +
           "AND (:employmentTypeId IS NULL OR e.employmentType.id = :employmentTypeId) " +
           "AND (:status IS NULL OR e.employmentStatus = :status) " +
           "AND (:isActive IS NULL OR e.isActive = :isActive)")
    Page<Employee> searchEmployeesWithFilters(
            @Param("orgId") Long organizationId,
            @Param("search") String search,
            @Param("departmentId") Long departmentId,
            @Param("branchId") Long branchId,
            @Param("employmentTypeId") Long employmentTypeId,
            @Param("status") String status,
            @Param("isActive") Boolean isActive,
            Pageable pageable);

    boolean existsByEmployeeNumber(String employeeNumber);

    boolean existsByOrganizationIdAndEmployeeNumber(Long organizationId, String employeeNumber);

    Long countByOrganizationId(Long organizationId);
    
    Long countByOrganizationIdAndIsActiveTrue(Long organizationId);
    
    Long countByDepartmentIdAndIsActiveTrue(Long departmentId);
}
