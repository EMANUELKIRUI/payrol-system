-- =====================================================
-- Update Payroll Components Table Schema
-- Align with PayrollComponent entity
-- =====================================================

-- Rename payroll_components columns (check if old column exists first)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_components' AND column_name = 'calculation_type') THEN
        ALTER TABLE payroll_components RENAME COLUMN calculation_type TO calculation_method;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_components' AND column_name = 'calculation_formula') THEN
        ALTER TABLE payroll_components RENAME COLUMN calculation_formula TO formula;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_components' AND column_name = 'default_amount') THEN
        ALTER TABLE payroll_components RENAME COLUMN default_amount TO fixed_amount;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_components' AND column_name = 'default_percentage') THEN
        ALTER TABLE payroll_components RENAME COLUMN default_percentage TO percentage_value;
    END IF;
    
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_components' AND column_name = 'affects_gross_pay') THEN
        ALTER TABLE payroll_components RENAME COLUMN affects_gross_pay TO affects_gross;
    END IF;
END $$;

-- Add missing columns to payroll_components
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS calculation_basis VARCHAR(30);
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS affects_net BOOLEAN DEFAULT TRUE;
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS display_on_payslip BOOLEAN DEFAULT TRUE;
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS priority_order INTEGER DEFAULT 0;
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Drop old column if exists
ALTER TABLE payroll_components DROP COLUMN IF EXISTS display_order;

-- Rename payroll_component_types columns
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_component_types' AND column_name = 'category') THEN
        ALTER TABLE payroll_component_types RENAME COLUMN category TO calculation_category;
    END IF;
END $$;

-- Add missing columns to payroll_component_types
ALTER TABLE payroll_component_types ADD COLUMN IF NOT EXISTS is_system_type BOOLEAN DEFAULT FALSE;
ALTER TABLE payroll_component_types ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE payroll_component_types ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Update comments (safe to run even if column already exists with this name)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payroll_component_types' AND column_name = 'calculation_category') THEN
        COMMENT ON COLUMN payroll_component_types.calculation_category IS 'EARNING, DEDUCTION, BENEFIT, TAX, STATUTORY';
    END IF;
END $$;
