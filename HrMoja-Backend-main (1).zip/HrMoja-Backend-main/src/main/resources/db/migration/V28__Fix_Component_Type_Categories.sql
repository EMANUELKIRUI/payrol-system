-- =====================================================
-- Fix Component Type Categories for Proper Tab Display
-- TAX components should be category='TAX'
-- STATUTORY components (NSSF, LST) should be category='STATUTORY'
-- =====================================================

-- Update Tax Deduction to TAX category
UPDATE payroll_component_types 
SET calculation_category = 'TAX'
WHERE code IN ('TAX', 'PAYE') 
  AND calculation_category = 'DEDUCTION';

-- Update Social Security to STATUTORY category
UPDATE payroll_component_types 
SET calculation_category = 'STATUTORY'
WHERE code IN ('SOCIAL_SECURITY', 'NSSF', 'LST', 'LOCAL_TAX') 
  AND calculation_category = 'DEDUCTION';

-- Create additional component types if needed
INSERT INTO payroll_component_types (name, code, description, calculation_category, is_system_type, is_active, created_at, updated_at)
VALUES 
    ('PAYE Tax', 'PAYE_TAX', 'Pay As You Earn income tax', 'TAX', TRUE, TRUE, NOW(), NOW())
ON CONFLICT (code) DO UPDATE 
SET calculation_category = 'TAX', 
    description = 'Pay As You Earn income tax',
    updated_at = NOW();

INSERT INTO payroll_component_types (name, code, description, calculation_category, is_system_type, is_active, created_at, updated_at)
VALUES 
    ('NSSF Contribution', 'NSSF_CONTRIB', 'National Social Security Fund contribution', 'STATUTORY', TRUE, TRUE, NOW(), NOW())
ON CONFLICT (code) DO UPDATE 
SET calculation_category = 'STATUTORY', 
    description = 'National Social Security Fund contribution',
    updated_at = NOW();

INSERT INTO payroll_component_types (name, code, description, calculation_category, is_system_type, is_active, created_at, updated_at)
VALUES 
    ('Local Service Tax', 'LST', 'Local Service Tax', 'STATUTORY', TRUE, TRUE, NOW(), NOW())
ON CONFLICT (code) DO UPDATE 
SET calculation_category = 'STATUTORY', 
    description = 'Local Service Tax',
    updated_at = NOW();

COMMENT ON TABLE payroll_component_types IS 'Component types: EARNING, DEDUCTION (voluntary), TAX, STATUTORY, BENEFIT';
