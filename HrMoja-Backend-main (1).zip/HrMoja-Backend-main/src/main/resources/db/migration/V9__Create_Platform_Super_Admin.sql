-- =====================================================
-- CREATE PLATFORM SUPER ADMIN
-- Version: 1.0
-- Description: Create initial platform super admin user
-- =====================================================

-- Insert Platform Super Admin User
-- Default Password: password (MUST BE CHANGED ON FIRST LOGIN)
-- BCrypt hash with strength 12
INSERT INTO users (
    username, 
    email, 
    password_hash, 
    first_name, 
    last_name, 
    phone_number,
    is_active, 
    is_locked,
    is_email_verified,
    failed_login_attempts,
    must_change_password,
    created_at,
    updated_at
) VALUES (
    'superadmin',
    'superadmin@hrmoja.com',
    '$2a$12$KvY1WsEpAkLHKPL2k/H.d.rAsqRGWvDOPZV7dIS6DyF/kNr0KYgAG',
    'Platform',
    'Administrator',
    '+256700000000',
    true,
    false,
    true,
    0,
    true,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
);

-- Assign SUPER_ADMIN role to the platform super admin
INSERT INTO user_roles (user_id, role_id, assigned_at)
SELECT u.id, r.id, CURRENT_TIMESTAMP
FROM users u
CROSS JOIN roles r
WHERE u.username = 'superadmin' 
AND r.code = 'SUPER_ADMIN';

-- Create a system comment/note
COMMENT ON TABLE users IS 'Platform super admin: username=superadmin, email=superadmin@hrmoja.com, default password=password (CHANGE IMMEDIATELY)';

-- Log the creation
DO $$
BEGIN
    RAISE NOTICE 'Platform Super Admin created successfully';
    RAISE NOTICE 'Username: superadmin';
    RAISE NOTICE 'Email: superadmin@hrmoja.com';
    RAISE NOTICE 'Default Password: password';
    RAISE NOTICE 'IMPORTANT: Change password immediately after first login!';
END $$;
