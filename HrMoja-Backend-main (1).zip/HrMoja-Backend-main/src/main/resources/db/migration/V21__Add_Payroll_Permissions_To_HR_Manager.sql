-- =====================================================
-- Add PAYROLL_MANAGE permission and assign payroll permissions to HR_MANAGER
-- Purpose: Allow HR Managers to manage and process payroll
-- =====================================================

-- First, ensure PAYROLL_MANAGE permission exists
INSERT INTO permissions (name, code, description, module, is_active)
VALUES ('Manage Payroll', 'PAYROLL_MANAGE', 'Create and manage payroll periods', 'PAYROLL_MANAGEMENT', true)
ON CONFLICT (code) DO NOTHING;

-- Add PAYROLL_MANAGE and PAYROLL_PROCESS permissions to HR_MANAGER role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'HR_MANAGER'
AND p.code IN ('PAYROLL_MANAGE', 'PAYROLL_PROCESS')
AND NOT EXISTS (
    SELECT 1 
    FROM role_permissions rp 
    WHERE rp.role_id = r.id 
    AND rp.permission_id = p.id
);

-- Verification query (commented out)
-- SELECT r.name as role_name, p.code as permission_code, p.name as permission_name
-- FROM roles r
-- JOIN role_permissions rp ON r.id = rp.role_id
-- JOIN permissions p ON rp.permission_id = p.id
-- WHERE r.code = 'HR_MANAGER'
-- AND p.code LIKE 'PAYROLL%'
-- ORDER BY p.code;
