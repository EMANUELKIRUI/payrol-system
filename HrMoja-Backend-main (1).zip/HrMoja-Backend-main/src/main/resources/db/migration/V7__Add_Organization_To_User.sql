-- =====================================================
-- ADD ORGANIZATION CONTEXT TO USER
-- Version: 7
-- Description: Link users to organizations for multi-tenancy
-- =====================================================

-- Add organization_id to users table
ALTER TABLE users ADD COLUMN organization_id BIGINT;

-- Add foreign key constraint
ALTER TABLE users ADD CONSTRAINT fk_users_organization 
    FOREIGN KEY (organization_id) REFERENCES organizations(id);

-- Create index for faster lookups
CREATE INDEX idx_users_organization ON users(organization_id);

-- Add organization context to employees (already has organization_id)
-- No changes needed for employees table as it already has organization_id

COMMENT ON COLUMN users.organization_id IS 'Organization context for multi-tenant support';
