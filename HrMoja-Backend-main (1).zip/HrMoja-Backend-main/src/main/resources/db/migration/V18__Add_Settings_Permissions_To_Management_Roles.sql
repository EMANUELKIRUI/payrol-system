-- Migration: Add SETTINGS_MANAGE permission to HR_MANAGER role
-- Purpose: Allow HR Managers to perform CRUD operations on all settings
-- Author: System
-- Date: 2025-10-26

-- Add SETTINGS_MANAGE permission to HR_MANAGER role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'HR_MANAGER'
AND p.code = 'SETTINGS_MANAGE'
AND NOT EXISTS (
    SELECT 1 
    FROM role_permissions rp 
    WHERE rp.role_id = r.id 
    AND rp.permission_id = p.id
);

-- Verification: Check HR_MANAGER now has both SETTINGS_READ and SETTINGS_MANAGE
-- SELECT r.name, p.code, p.name
-- FROM roles r
-- JOIN role_permissions rp ON r.id = rp.role_id
-- JOIN permissions p ON rp.permission_id = p.id
-- WHERE r.code = 'HR_MANAGER'
-- AND p.code LIKE 'SETTINGS%'
-- ORDER BY p.code;
