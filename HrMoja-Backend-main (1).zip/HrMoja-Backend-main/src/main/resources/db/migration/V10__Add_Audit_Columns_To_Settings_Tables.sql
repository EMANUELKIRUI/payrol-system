-- Add audit columns to all settings tables

-- Countries
ALTER TABLE countries ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE countries ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Organizations
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Branches
ALTER TABLE branches ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE branches ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Banks
ALTER TABLE banks ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE banks ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Bank Branches
ALTER TABLE bank_branches ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE bank_branches ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Pay Frequencies
ALTER TABLE pay_frequencies ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE pay_frequencies ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Employment Types
ALTER TABLE employment_types ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE employment_types ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Payment Methods
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Employee Grades
ALTER TABLE employee_grades ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE employee_grades ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- System Configurations
ALTER TABLE system_configurations ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE system_configurations ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Tax Brackets
ALTER TABLE tax_brackets ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE tax_brackets ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Statutory Configurations
ALTER TABLE statutory_configurations ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE statutory_configurations ADD COLUMN IF NOT EXISTS updated_by BIGINT;
