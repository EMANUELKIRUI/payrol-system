-- Add missing audit columns to departments table
ALTER TABLE departments 
ADD COLUMN IF NOT EXISTS created_by BIGINT,
ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add comments
COMMENT ON COLUMN departments.created_by IS 'User ID who created this record';
COMMENT ON COLUMN departments.updated_by IS 'User ID who last updated this record';
