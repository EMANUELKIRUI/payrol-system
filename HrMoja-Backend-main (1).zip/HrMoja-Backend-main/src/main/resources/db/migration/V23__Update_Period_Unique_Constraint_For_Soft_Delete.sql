-- Migration: Update payroll_periods unique constraint to allow same dates for DELETED periods
-- This enables recreation of periods after soft deletion

-- Drop the old unique constraint
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS uk_period_org_dates;

-- Create a partial unique index that only applies to non-DELETED records
-- This allows multiple DELETED records with same dates, but prevents duplicate active periods
CREATE UNIQUE INDEX uk_period_org_dates_active 
ON payroll_periods (organization_id, start_date, end_date) 
WHERE status != 'DELETED';

-- Add comment for documentation
COMMENT ON INDEX uk_period_org_dates_active IS 'Ensures unique periods per organization and dates, excluding DELETED records';
