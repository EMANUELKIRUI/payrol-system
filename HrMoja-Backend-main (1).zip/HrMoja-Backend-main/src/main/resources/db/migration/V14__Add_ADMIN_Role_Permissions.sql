-- =====================================================
-- Add ADMIN Role Permissions
-- Version: 1.0
-- Description: Minimal permissions for ADMIN role - IT/Access Management
--              ADMIN can: Manage users, view roles for assignment, manage organization
--              ADMIN cannot: Manage roles/permissions (ROLE_MANAGE is SUPER_ADMIN only)
-- =====================================================

-- ADMIN Permissions Summary:
-- ✅ USER_MANAGE (from V12) - Manage users AND view roles for assignment
-- ✅ SETTINGS_READ - View organization settings
-- ✅ SETTINGS_MANAGE - Update organization configuration
-- ❌ ROLE_MANAGE - SUPER_ADMIN only (cannot create/edit/delete roles)

-- Assign organization management permissions to ADMIN role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'ADMIN'
AND p.code IN (
    -- Organization management
    'SETTINGS_READ',
    'SETTINGS_MANAGE'
)
ON CONFLICT DO NOTHING;

COMMENT ON TABLE role_permissions IS 'ADMIN role: USER_MANAGE (V12) + organization settings management only';
