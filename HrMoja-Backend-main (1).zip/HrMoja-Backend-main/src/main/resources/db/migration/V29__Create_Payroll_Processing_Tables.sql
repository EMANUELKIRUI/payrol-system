-- =====================================================
-- Payroll Processing Tables
-- Payroll Periods, Runs, and Employee Payroll Records
-- =====================================================

-- Update existing payroll_periods table with new columns
ALTER TABLE payroll_periods 
    ADD COLUMN IF NOT EXISTS period_type VARCHAR(20) DEFAULT 'MONTHLY',
    ADD COLUMN IF NOT EXISTS total_gross_pay DECIMAL(15, 2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS total_deductions DECIMAL(15, 2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS total_net_pay DECIMAL(15, 2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- Drop old constraints first to avoid conflicts during updates
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS check_period_status;
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS check_status;
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS check_dates;
DROP INDEX IF EXISTS uk_period_org_dates_active;

-- Handle duplicate records: Mark older duplicates (lower ID) as DELETED
-- Keep only the most recent record (highest ID) for each org/date combination
UPDATE payroll_periods p1
SET status = 'DELETED'
WHERE status NOT IN ('DELETED')
AND EXISTS (
    SELECT 1 FROM payroll_periods p2
    WHERE p2.organization_id = p1.organization_id
    AND p2.start_date = p1.start_date
    AND p2.end_date = p1.end_date
    AND p2.id > p1.id
    AND p2.status NOT IN ('DELETED')
);

-- Update old status values to match new schema
UPDATE payroll_periods SET status = 'PROCESSING' WHERE status = 'IN_PROGRESS';
UPDATE payroll_periods SET status = 'APPROVED' WHERE status = 'PENDING_APPROVAL';
UPDATE payroll_periods SET status = 'CLOSED' WHERE status = 'LOCKED';

-- Add new status constraint
ALTER TABLE payroll_periods ADD CONSTRAINT check_period_status 
    CHECK (status IN ('DRAFT', 'PROCESSING', 'APPROVED', 'PAID', 'CLOSED', 'DELETED'));

-- Recreate the partial unique index (allows multiple DELETED, but unique for active periods)
CREATE UNIQUE INDEX IF NOT EXISTS uk_period_org_dates_active 
ON payroll_periods (organization_id, start_date, end_date) 
WHERE status != 'DELETED';

-- Payroll Runs (Processing history for each period)
CREATE TABLE IF NOT EXISTS payroll_runs (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL REFERENCES payroll_periods(id) ON DELETE CASCADE,
    run_number INTEGER NOT NULL,
    run_type VARCHAR(20) NOT NULL, -- REGULAR, ADJUSTMENT, BONUS, OFF_CYCLE
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT', -- DRAFT, PROCESSING, COMPLETED, FAILED
    total_employees_processed INTEGER DEFAULT 0,
    total_employees_failed INTEGER DEFAULT 0,
    total_gross_pay DECIMAL(15, 2) DEFAULT 0,
    total_deductions DECIMAL(15, 2) DEFAULT 0,
    total_net_pay DECIMAL(15, 2) DEFAULT 0,
    processing_started_at TIMESTAMP,
    processing_completed_at TIMESTAMP,
    error_log TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    CONSTRAINT check_run_status CHECK (status IN ('DRAFT', 'PROCESSING', 'COMPLETED', 'FAILED'))
);

-- Employee Payroll Records (Individual payroll for each employee in a period)
CREATE TABLE IF NOT EXISTS employee_payroll_records (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL REFERENCES payroll_periods(id) ON DELETE CASCADE,
    payroll_run_id BIGINT REFERENCES payroll_runs(id),
    employee_id BIGINT NOT NULL REFERENCES employees(id),
    employee_name VARCHAR(255),
    employee_number VARCHAR(50),
    department_name VARCHAR(100),
    position_title VARCHAR(100),
    
    -- Salary Information
    basic_salary DECIMAL(15, 2) NOT NULL DEFAULT 0,
    gross_salary DECIMAL(15, 2) NOT NULL DEFAULT 0,
    taxable_income DECIMAL(15, 2) NOT NULL DEFAULT 0,
    pensionable_income DECIMAL(15, 2) NOT NULL DEFAULT 0,
    
    -- Totals
    total_earnings DECIMAL(15, 2) NOT NULL DEFAULT 0,
    total_deductions DECIMAL(15, 2) NOT NULL DEFAULT 0,
    total_statutory DECIMAL(15, 2) NOT NULL DEFAULT 0,
    total_taxes DECIMAL(15, 2) NOT NULL DEFAULT 0,
    net_salary DECIMAL(15, 2) NOT NULL DEFAULT 0,
    
    -- Days & Hours
    days_worked DECIMAL(5, 2) DEFAULT 0,
    days_absent DECIMAL(5, 2) DEFAULT 0,
    overtime_hours DECIMAL(5, 2) DEFAULT 0,
    
    -- Status
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT', -- DRAFT, CALCULATED, APPROVED, PAID
    calculation_errors TEXT,
    is_paid BOOLEAN DEFAULT FALSE,
    payment_date TIMESTAMP,
    payment_method VARCHAR(50), -- BANK_TRANSFER, CHEQUE, CASH, MOBILE_MONEY
    payment_reference VARCHAR(100),
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_by BIGINT,
    
    UNIQUE(payroll_period_id, employee_id),
    CONSTRAINT check_record_status CHECK (status IN ('DRAFT', 'CALCULATED', 'APPROVED', 'PAID'))
);

-- Payroll Line Items (Individual earnings/deductions for each employee)
CREATE TABLE IF NOT EXISTS payroll_line_items (
    id BIGSERIAL PRIMARY KEY,
    employee_payroll_record_id BIGINT NOT NULL REFERENCES employee_payroll_records(id) ON DELETE CASCADE,
    component_id BIGINT REFERENCES payroll_components(id),
    component_name VARCHAR(200) NOT NULL,
    component_code VARCHAR(50) NOT NULL,
    component_category VARCHAR(50) NOT NULL, -- EARNING, DEDUCTION, TAX, STATUTORY, BENEFIT
    
    -- Calculation Details
    calculation_method VARCHAR(30), -- FIXED, PERCENTAGE, FORMULA, RANGE
    calculation_basis VARCHAR(50), -- BASIC_SALARY, GROSS_SALARY, TAXABLE_INCOME
    rate_or_amount DECIMAL(15, 2),
    quantity DECIMAL(10, 2) DEFAULT 1,
    
    -- Amount
    amount DECIMAL(15, 2) NOT NULL DEFAULT 0,
    
    -- Flags
    is_taxable BOOLEAN DEFAULT TRUE,
    is_pensionable BOOLEAN DEFAULT TRUE,
    is_statutory BOOLEAN DEFAULT FALSE,
    
    display_order INTEGER DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payroll Audit Trail
CREATE TABLE IF NOT EXISTS payroll_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT REFERENCES payroll_periods(id),
    employee_payroll_record_id BIGINT REFERENCES employee_payroll_records(id),
    action VARCHAR(50) NOT NULL, -- CREATE, UPDATE, APPROVE, REJECT, RECALCULATE, PAY
    performed_by BIGINT NOT NULL,
    performed_by_name VARCHAR(255),
    old_values JSONB,
    new_values JSONB,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_payroll_periods_org_date ON payroll_periods(organization_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_status ON payroll_periods(status, is_active);
CREATE INDEX IF NOT EXISTS idx_payroll_runs_period ON payroll_runs(payroll_period_id, run_number);
CREATE INDEX IF NOT EXISTS idx_employee_payroll_period ON employee_payroll_records(payroll_period_id, employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_payroll_status ON employee_payroll_records(status, is_paid);
CREATE INDEX IF NOT EXISTS idx_payroll_line_items_record ON payroll_line_items(employee_payroll_record_id, component_category);
CREATE INDEX IF NOT EXISTS idx_payroll_audit_period ON payroll_audit_logs(payroll_period_id, created_at);

-- Comments
COMMENT ON TABLE payroll_periods IS 'Payroll periods (monthly, bi-weekly, etc.) for processing payroll';
COMMENT ON TABLE payroll_runs IS 'Processing runs for each payroll period (can have multiple runs for adjustments)';
COMMENT ON TABLE employee_payroll_records IS 'Individual employee payroll records for each period';
COMMENT ON TABLE payroll_line_items IS 'Detailed line items (earnings, deductions) for each employee payroll record';
COMMENT ON TABLE payroll_audit_logs IS 'Audit trail for all payroll actions and changes';

COMMENT ON COLUMN employee_payroll_records.gross_salary IS 'Total earnings before any deductions';
COMMENT ON COLUMN employee_payroll_records.taxable_income IS 'Income subject to PAYE tax (Gross - NSSF - LST)';
COMMENT ON COLUMN employee_payroll_records.pensionable_income IS 'Income subject to NSSF contributions';
COMMENT ON COLUMN employee_payroll_records.net_salary IS 'Take-home pay after all deductions';
