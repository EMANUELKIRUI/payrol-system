-- =====================================================
-- SEED DATA
-- Version: 1.0
-- Description: Initial system data and configurations
-- =====================================================

-- Insert Default Permissions
INSERT INTO permissions (name, code, description, module, is_active) VALUES
-- User Management
('View Users', 'USER_READ', 'View user information', 'USER_MANAGEMENT', true),
('Create Users', 'USER_CREATE', 'Create new users', 'USER_MANAGEMENT', true),
('Edit Users', 'USER_UPDATE', 'Edit user information', 'USER_MANAGEMENT', true),
('Delete Users', 'USER_DELETE', 'Delete users', 'USER_MANAGEMENT', true),
('Manage Roles', 'ROLE_MANAGE', 'Manage user roles', 'USER_MANAGEMENT', true),

-- Employee Management
('View Employees', 'EMPLOYEE_READ', 'View employee information', 'EMPLOYEE_MANAGEMENT', true),
('Create Employees', 'EMPLOYEE_CREATE', 'Create new employees', 'EMPLOYEE_MANAGEMENT', true),
('Edit Employees', 'EMPLOYEE_UPDATE', 'Edit employee information', 'EMPLOYEE_MANAGEMENT', true),
('Delete Employees', 'EMPLOYEE_DELETE', 'Delete employees', 'EMPLOYEE_MANAGEMENT', true),

-- Payroll Management
('View Payroll', 'PAYROLL_READ', 'View payroll information', 'PAYROLL_MANAGEMENT', true),
('Create Payroll', 'PAYROLL_CREATE', 'Create payroll periods and inputs', 'PAYROLL_MANAGEMENT', true),
('Process Payroll', 'PAYROLL_PROCESS', 'Process payroll calculations', 'PAYROLL_MANAGEMENT', true),
('Approve Payroll', 'PAYROLL_APPROVE', 'Approve processed payroll', 'PAYROLL_MANAGEMENT', true),
('Pay Payroll', 'PAYROLL_PAY', 'Disburse salary payments', 'PAYROLL_MANAGEMENT', true),

-- Settings
('View Settings', 'SETTINGS_READ', 'View system settings', 'SETTINGS', true),
('Manage Settings', 'SETTINGS_MANAGE', 'Manage system configurations', 'SETTINGS', true),

-- Reports
('View Reports', 'REPORTS_READ', 'View reports', 'REPORTS', true),
('Export Reports', 'REPORTS_EXPORT', 'Export reports', 'REPORTS', true);

-- Insert Default Roles
INSERT INTO roles (name, code, description, level, is_system_role, is_active) VALUES
('Super Administrator', 'SUPER_ADMIN', 'Full system access', 1, true, true),
('Administrator', 'ADMIN', 'Administrative access', 2, true, true),
('HR Manager', 'HR_MANAGER', 'HR management access', 3, true, true),
('Payroll Manager', 'PAYROLL_MANAGER', 'Payroll management access', 4, true, true),
('Finance Manager', 'FINANCE_MANAGER', 'Finance and approval access', 4, true, true),
('Manager', 'MANAGER', 'Departmental manager access', 5, true, true),
('Employee', 'EMPLOYEE', 'Basic employee access', 6, true, true);

-- Assign Permissions to Super Admin Role (ALL permissions)
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'SUPER_ADMIN';

-- Assign Permissions to HR Manager Role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'HR_MANAGER'
AND p.code IN ('USER_READ', 'EMPLOYEE_READ', 'EMPLOYEE_CREATE', 'EMPLOYEE_UPDATE', 
               'PAYROLL_READ', 'SETTINGS_READ', 'REPORTS_READ', 'REPORTS_EXPORT');

-- Assign Permissions to Payroll Manager Role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'PAYROLL_MANAGER'
AND p.code IN ('EMPLOYEE_READ', 'PAYROLL_READ', 'PAYROLL_CREATE', 'PAYROLL_PROCESS', 
               'SETTINGS_READ', 'REPORTS_READ', 'REPORTS_EXPORT');

-- Assign Permissions to Finance Manager Role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'FINANCE_MANAGER'
AND p.code IN ('PAYROLL_READ', 'PAYROLL_APPROVE', 'PAYROLL_PAY', 
               'REPORTS_READ', 'REPORTS_EXPORT');

-- Insert Countries
INSERT INTO countries (name, code, iso_code, currency_code, currency_name, currency_symbol, timezone, is_active) VALUES
('Uganda', 'UGA', 'UG', 'UGX', 'Uganda Shilling', 'USh', 'Africa/Kampala', true),
('Kenya', 'KEN', 'KE', 'KES', 'Kenyan Shilling', 'KSh', 'Africa/Nairobi', true),
('Zambia', 'ZMB', 'ZM', 'ZMW', 'Zambian Kwacha', 'ZK', 'Africa/Lusaka', true);

-- Insert Pay Frequencies
INSERT INTO pay_frequencies (name, code, description, periods_per_year, is_active) VALUES
('Monthly', 'MONTHLY', 'Monthly payroll - 12 periods per year', 12, true),
('Bi-Weekly', 'BI_WEEKLY', 'Bi-weekly payroll - 26 periods per year', 26, true),
('Weekly', 'WEEKLY', 'Weekly payroll - 52 periods per year', 52, true),
('Semi-Monthly', 'SEMI_MONTHLY', 'Semi-monthly payroll - 24 periods per year', 24, true);

-- Insert Employment Types
INSERT INTO employment_types (name, code, description, is_active) VALUES
('Permanent', 'PERMANENT', 'Permanent employment', true),
('Contract', 'CONTRACT', 'Fixed-term contract', true),
('Part-Time', 'PART_TIME', 'Part-time employment', true),
('Temporary', 'TEMPORARY', 'Temporary employment', true),
('Intern', 'INTERN', 'Internship', true),
('Consultant', 'CONSULTANT', 'Consultant/Freelance', true);

-- Insert Payment Methods
INSERT INTO payment_methods (name, code, description, is_active) VALUES
('Electronic Fund Transfer', 'EFT', 'Bank transfer/EFT', true),
('Bank Deposit', 'BANK_DEPOSIT', 'Direct bank deposit', true),
('Mobile Money', 'MOBILE_MONEY', 'Mobile money transfer', true),
('Cash', 'CASH', 'Cash payment', true),
('Cheque', 'CHEQUE', 'Bank cheque', true);

-- Insert Payroll Component Types
INSERT INTO payroll_component_types (name, code, category, description, is_active) VALUES
('Basic Salary', 'BASIC_SALARY', 'EARNING', 'Base salary component', true),
('Allowance', 'ALLOWANCE', 'EARNING', 'Various allowances', true),
('Bonus', 'BONUS', 'EARNING', 'Performance and other bonuses', true),
('Commission', 'COMMISSION', 'EARNING', 'Sales commissions', true),
('Overtime', 'OVERTIME', 'EARNING', 'Overtime payments', true),
('Tax Deduction', 'TAX', 'DEDUCTION', 'Tax deductions (PAYE)', true),
('Social Security', 'SOCIAL_SECURITY', 'DEDUCTION', 'Social security contributions', true),
('Loan Repayment', 'LOAN', 'DEDUCTION', 'Loan repayments', true),
('Other Deduction', 'OTHER_DEDUCTION', 'DEDUCTION', 'Other deductions', true),
('Employer Contribution', 'EMPLOYER_CONTRIB', 'CONTRIBUTION', 'Employer contributions', true);

-- Insert Uganda Tax Brackets (2024 rates)
INSERT INTO tax_brackets (country_id, tax_year, bracket_name, min_amount, max_amount, tax_rate, fixed_amount, effective_date, is_active)
SELECT c.id, 2024, 'Band 1', 0, 235000, 0, 0, '2024-01-01'::date, true FROM countries c WHERE c.code = 'UGA'
UNION ALL
SELECT c.id, 2024, 'Band 2', 235001, 335000, 10, 0, '2024-01-01'::date, true FROM countries c WHERE c.code = 'UGA'
UNION ALL
SELECT c.id, 2024, 'Band 3', 335001, 410000, 20, 10000, '2024-01-01'::date, true FROM countries c WHERE c.code = 'UGA'
UNION ALL
SELECT c.id, 2024, 'Band 4', 410001, 10000000, 30, 25000, '2024-01-01'::date, true FROM countries c WHERE c.code = 'UGA'
UNION ALL
SELECT c.id, 2024, 'Band 5', 10000001, NULL, 40, 2902000, '2024-01-01'::date, true FROM countries c WHERE c.code = 'UGA';

-- Insert Statutory Configuration for Uganda
INSERT INTO statutory_configurations (country_id, statutory_type, name, description, effective_date, configuration_data, is_active)
SELECT 
    c.id, 
    'NSSF', 
    'NSSF - Uganda',
    'National Social Security Fund contributions',
    '2024-01-01'::date,
    '{"employee_rate": 5, "employer_rate": 10, "ceiling": 500000, "mandatory": true}'::jsonb,
    true
FROM countries c WHERE c.code = 'UGA';

INSERT INTO statutory_configurations (country_id, statutory_type, name, description, effective_date, configuration_data, is_active)
SELECT 
    c.id, 
    'LST', 
    'Local Service Tax - Uganda',
    'Local Service Tax',
    '2024-01-01'::date,
    '{"annual_amount": 60000, "monthly_amount": 5000}'::jsonb,
    true
FROM countries c WHERE c.code = 'UGA';

-- Insert Default System Configurations
INSERT INTO system_configurations (config_key, config_value, data_type, category, description, is_editable) VALUES
('system.name', 'HRMoja', 'STRING', 'GENERAL', 'System name', true),
('system.default_country', 'UGA', 'STRING', 'GENERAL', 'Default country code', true),
('system.default_currency', 'UGX', 'STRING', 'GENERAL', 'Default currency', true),
('payroll.default_frequency', 'MONTHLY', 'STRING', 'PAYROLL', 'Default payroll frequency', true),
('payroll.auto_process', 'false', 'BOOLEAN', 'PAYROLL', 'Auto-process payroll', true),
('email.from_address', 'noreply@hrmoja.com', 'STRING', 'EMAIL', 'Email from address', true),
('email.from_name', 'HRMoja System', 'STRING', 'EMAIL', 'Email from name', true);

COMMENT ON TABLE permissions IS 'Seeded with default system permissions';
COMMENT ON TABLE roles IS 'Seeded with default system roles';
COMMENT ON TABLE countries IS 'Seeded with Uganda, Kenya, Zambia';
