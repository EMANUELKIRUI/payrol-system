-- =====================================================
-- Add ROLE_MANAGE Permission for Role & Permission Management
-- Version: 1.0
-- Description: Separate role/permission management from user management
--              Only SUPER_ADMIN should manage roles and permissions
--              ADMIN can manage users but not roles/permissions
-- =====================================================

-- Insert ROLE_MANAGE permission
INSERT INTO permissions (name, code, description, module, is_active) VALUES
('Manage Roles', 'ROLE_MANAGE', 'Full role and permission management access (CRUD, assign permissions)', 'USER_MANAGEMENT', true)
ON CONFLICT (code) DO NOTHING;

-- Assign ROLE_MANAGE to SUPER_ADMIN role ONLY
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'SUPER_ADMIN'
AND p.code = 'ROLE_MANAGE'
ON CONFLICT DO NOTHING;

COMMENT ON TABLE permissions IS 'Added ROLE_MANAGE permission - only SUPER_ADMIN can manage roles and permissions';
