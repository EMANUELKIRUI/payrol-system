-- Add missing audit columns to job_titles table
ALTER TABLE job_titles 
ADD COLUMN IF NOT EXISTS created_by BIGINT,
ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add comments
COMMENT ON COLUMN job_titles.created_by IS 'User ID who created this record';
COMMENT ON COLUMN job_titles.updated_by IS 'User ID who last updated this record';
