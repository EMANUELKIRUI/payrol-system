-- =====================================================
-- Fix Payroll Periods Table Schema
-- Add missing columns to match PayrollPeriod entity
-- =====================================================

-- Add missing columns for approval tracking
ALTER TABLE payroll_periods 
ADD COLUMN IF NOT EXISTS approved_by BIGINT,
ADD COLUMN IF NOT EXISTS approved_at DATE;

-- Add missing columns for processing tracking
ALTER TABLE payroll_periods 
ADD COLUMN IF NOT EXISTS processed_by BIGINT,
ADD COLUMN IF NOT EXISTS processed_at DATE,
ADD COLUMN IF NOT EXISTS processed_employees INTEGER DEFAULT 0;

-- Add missing period identification columns
ALTER TABLE payroll_periods 
ADD COLUMN IF NOT EXISTS period_code VARCHAR(50),
ADD COLUMN IF NOT EXISTS period_year INTEGER,
ADD COLUMN IF NOT EXISTS period_month INTEGER;

-- Add pay frequency foreign key column if it doesn't exist
ALTER TABLE payroll_periods 
ADD COLUMN IF NOT EXISTS pay_frequency_id BIGINT;

-- Rename columns to match entity (only if the column exists)
DO $$ 
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'payroll_periods' AND column_name = 'pay_date'
    ) THEN
        ALTER TABLE payroll_periods RENAME COLUMN pay_date TO payment_date;
    END IF;
END $$;

-- Add foreign key constraints for new columns
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_payroll_periods_approved_by'
    ) THEN
        ALTER TABLE payroll_periods 
        ADD CONSTRAINT fk_payroll_periods_approved_by 
        FOREIGN KEY (approved_by) REFERENCES users(id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_payroll_periods_processed_by'
    ) THEN
        ALTER TABLE payroll_periods 
        ADD CONSTRAINT fk_payroll_periods_processed_by 
        FOREIGN KEY (processed_by) REFERENCES users(id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_payroll_periods_pay_frequency'
    ) THEN
        ALTER TABLE payroll_periods 
        ADD CONSTRAINT fk_payroll_periods_pay_frequency 
        FOREIGN KEY (pay_frequency_id) REFERENCES pay_frequencies(id);
    END IF;
END $$;

-- Update existing records with default values for new columns
UPDATE payroll_periods 
SET 
    period_code = CONCAT('PAY-', id),
    period_year = EXTRACT(YEAR FROM start_date)::INTEGER,
    period_month = EXTRACT(MONTH FROM start_date)::INTEGER
WHERE period_code IS NULL;

-- Make period_code NOT NULL after populating
ALTER TABLE payroll_periods 
ALTER COLUMN period_code SET NOT NULL;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_payroll_periods_approved_by ON payroll_periods(approved_by);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_processed_by ON payroll_periods(processed_by);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_pay_frequency ON payroll_periods(pay_frequency_id);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_period_code ON payroll_periods(period_code);

COMMENT ON COLUMN payroll_periods.approved_by IS 'User who approved the payroll period';
COMMENT ON COLUMN payroll_periods.approved_at IS 'Date when payroll was approved';
COMMENT ON COLUMN payroll_periods.processed_by IS 'User who processed the payroll';
COMMENT ON COLUMN payroll_periods.processed_at IS 'Date when payroll was processed';
COMMENT ON COLUMN payroll_periods.processed_employees IS 'Number of employees processed in this period';
COMMENT ON COLUMN payroll_periods.period_code IS 'Unique period code identifier';
COMMENT ON COLUMN payroll_periods.period_year IS 'Year of the payroll period';
COMMENT ON COLUMN payroll_periods.period_month IS 'Month of the payroll period';
