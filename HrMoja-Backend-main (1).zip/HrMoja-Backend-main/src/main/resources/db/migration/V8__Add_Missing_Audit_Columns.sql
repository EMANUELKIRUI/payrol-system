-- Add missing audit columns to tables that don't have them

-- Add created_by and updated_by to permissions table
ALTER TABLE permissions ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE permissions ADD COLUMN IF NOT EXISTS updated_by BIGINT;

ALTER TABLE permissions ADD CONSTRAINT fk_permissions_created_by 
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE permissions ADD CONSTRAINT fk_permissions_updated_by 
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

-- Add created_by and updated_by to roles table
ALTER TABLE roles ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE roles ADD COLUMN IF NOT EXISTS updated_by BIGINT;

ALTER TABLE roles ADD CONSTRAINT fk_roles_created_by 
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE roles ADD CONSTRAINT fk_roles_updated_by 
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

-- Add created_by and updated_by to payroll_component_types table (if missing)
ALTER TABLE payroll_component_types ADD COLUMN IF NOT EXISTS created_by BIGINT;
ALTER TABLE payroll_component_types ADD COLUMN IF NOT EXISTS updated_by BIGINT;

ALTER TABLE payroll_component_types ADD CONSTRAINT fk_payroll_component_types_created_by 
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE payroll_component_types ADD CONSTRAINT fk_payroll_component_types_updated_by 
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_permissions_created_by ON permissions(created_by);
CREATE INDEX IF NOT EXISTS idx_permissions_updated_by ON permissions(updated_by);
CREATE INDEX IF NOT EXISTS idx_roles_created_by ON roles(created_by);
CREATE INDEX IF NOT EXISTS idx_roles_updated_by ON roles(updated_by);
