-- =====================================================
-- Uganda 2025 Tax Configuration Seed Data
-- Based on Uganda_Payroll_Rules_2025_Full.md
-- =====================================================

-- Insert Uganda Tax Configuration for 2025
INSERT INTO payroll_tax_configurations (organization_id, country_code, tax_year, effective_from, is_active, description)
VALUES (1, 'UG', 2025, '2025-01-01', TRUE, 'Uganda PAYE and statutory deductions for 2025')
ON CONFLICT (organization_id, country_code, tax_year, effective_from) DO NOTHING;

-- Get the configuration ID for Uganda 2025
DO $$
DECLARE
    config_id BIGINT;
BEGIN
    SELECT id INTO config_id FROM payroll_tax_configurations WHERE country_code = 'UG' AND tax_year = 2025 LIMIT 1;

    -- Uganda PAYE Tax Brackets (Monthly)
    -- Band 1: 0 – 235,000 @ 0%
    INSERT INTO payroll_tax_brackets (tax_configuration_id, bracket_number, min_income, max_income, tax_rate, fixed_amount, description)
    VALUES (config_id, 1, 0, 235000, 0, 0, 'Tax-free threshold')
    ON CONFLICT DO NOTHING;

    -- Band 2: 235,001 – 335,000 @ 10%
    INSERT INTO payroll_tax_brackets (tax_configuration_id, bracket_number, min_income, max_income, tax_rate, fixed_amount, description)
    VALUES (config_id, 2, 235001, 335000, 10, 0, '10% on excess over 235,000')
    ON CONFLICT DO NOTHING;

    -- Band 3: 335,001 – 410,000 @ 20%
    INSERT INTO payroll_tax_brackets (tax_configuration_id, bracket_number, min_income, max_income, tax_rate, fixed_amount, description)
    VALUES (config_id, 3, 335001, 410000, 20, 10000, '10,000 + 20% on excess over 335,000')
    ON CONFLICT DO NOTHING;

    -- Band 4: 410,001 – 10,000,000 @ 30%
    INSERT INTO payroll_tax_brackets (tax_configuration_id, bracket_number, min_income, max_income, tax_rate, fixed_amount, description)
    VALUES (config_id, 4, 410001, 10000000, 30, 25000, '25,000 + 30% on excess over 410,000')
    ON CONFLICT DO NOTHING;

    -- Band 5: Above 10,000,000 @ 40%
    INSERT INTO payroll_tax_brackets (tax_configuration_id, bracket_number, min_income, max_income, tax_rate, fixed_amount, description)
    VALUES (config_id, 5, 10000001, NULL, 40, 2902000, '2,902,000 + 40% on excess')
    ON CONFLICT DO NOTHING;

    -- Uganda Tax Reliefs (Minimal - mainly exemptions, not reliefs like Kenya)
    -- Tax-free threshold is already in bracket 1, but we can document exemptions
    INSERT INTO payroll_tax_reliefs (tax_configuration_id, relief_code, relief_name, relief_type, fixed_amount, is_mandatory, description)
    VALUES (config_id, 'NSSF_DEDUCTION', 'NSSF Employee Contribution Deduction', 'PERCENTAGE', NULL, TRUE, 
            'NSSF employee contribution (5%) is deducted before calculating taxable income')
    ON CONFLICT DO NOTHING;

    INSERT INTO payroll_tax_reliefs (tax_configuration_id, relief_code, relief_name, relief_type, fixed_amount, is_mandatory, description)
    VALUES (config_id, 'LST_DEDUCTION', 'Local Service Tax Deduction', 'FIXED', NULL, TRUE, 
            'LST paid is deductible from taxable income')
    ON CONFLICT DO NOTHING;

    -- Uganda Statutory Ceilings
    -- NSSF: No explicit ceiling mentioned in the document, but we track it here for future updates
    INSERT INTO payroll_statutory_ceilings (organization_id, country_code, contribution_type, ceiling_amount, effective_from, is_active, tier_structure)
    VALUES (1, 'UG', 'NSSF', NULL, '2025-01-01', TRUE, 
            '{"employee_rate": 5, "employer_rate": 10, "note": "No ceiling specified - calculate on full gross salary"}')
    ON CONFLICT DO NOTHING;

    -- LST (Local Service Tax) - Annual, typically UGX 5,000 - 100,000
    INSERT INTO payroll_statutory_ceilings (organization_id, country_code, contribution_type, ceiling_amount, effective_from, is_active, tier_structure)
    VALUES (1, 'UG', 'LST', 100000, '2025-01-01', TRUE, 
            '{"min_amount": 5000, "max_amount": 100000, "frequency": "annual", "remittance_deadline": "November 15"}')
    ON CONFLICT DO NOTHING;

END $$;

-- Component types already exist from previous migrations, skipping insert

COMMENT ON TABLE payroll_tax_configurations IS 'Uganda 2025: 5 PAYE brackets, NSSF (5%+10%), LST (5K-100K annual)';
