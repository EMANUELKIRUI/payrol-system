#!/bin/bash

# HRMoja Stop Script
# This script stops all running containers

set -e

GREEN='\033[0;32m'
NC='\033[0m'

print_message() {
    echo -e "${GREEN}[HRMoja]${NC} $1"
}

print_message "Stopping HRMoja services..."

# Stop containers
docker-compose down

print_message "All services stopped successfully!"
