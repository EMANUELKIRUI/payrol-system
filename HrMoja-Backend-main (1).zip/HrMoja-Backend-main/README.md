# HRMoja - HR Management System (Backend)

## 🎯 Overview

HRMoja is a comprehensive, scalable HR Management System built with Spring Boot, designed primarily for Uganda with scalability to Kenya and Zambia markets.

## 🚀 Features

### Core Modules (Phase 1)
- **User Management** - Authentication, roles, and permissions with RBAC
- **Employee Management** - Complete employee lifecycle management
- **Payroll Management** - Full payroll processing with Uganda statutory compliance
- **Settings Module** - Database-driven configuration system

## 🛠️ Technology Stack

- **Framework**: Spring Boot 3.2.0
- **Java**: 21
- **Database**: PostgreSQL
- **Migration**: Flyway
- **Security**: Spring Security + JWT
- **Documentation**: SpringDoc OpenAPI (Swagger)
- **Build Tool**: Maven
- **Testing**: JUnit 5, Mockito

## 📋 Prerequisites

- Java 21 or higher
- Maven 3.8+
- PostgreSQL 14+
- IDE (IntelliJ IDEA, Eclipse, or VS Code)

## 🔧 Setup Instructions

### 1. Clone the Repository
```bash
git clone <repository-url>
cd BE
```

### 2. Database Setup
```sql
-- Create database
CREATE DATABASE hrmoja_db;

-- Create user (optional)
CREATE USER hrmoja_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE hrmoja_db TO hrmoja_user;
```

### 3. Configure Environment
```bash
# Copy the example env file
cp .env.example .env

# Edit .env with your configurations
nano .env
```

### 4. Build the Project
```bash
mvn clean install
```

### 5. Run Database Migrations
```bash
mvn flyway:migrate
```

### 6. Run the Application
```bash
mvn spring-boot:run
```

Or run with specific profile:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

## 📚 API Documentation

Once the application is running, access the API documentation at:
- Swagger UI: http://localhost:8080/api/swagger-ui.html
- OpenAPI Spec: http://localhost:8080/api/v1/api-docs

## 🗂️ Project Structure

```
src/main/java/com/hrmoja/
├── config/              # Configuration classes
├── controller/          # REST controllers
├── dto/                 # Data Transfer Objects
├── entity/              # JPA entities
├── repository/          # Data access layer
├── service/             # Business logic layer
├── security/            # Security configurations
├── exception/           # Custom exceptions
├── util/                # Utility classes
└── HrMojaApplication.java

src/main/resources/
├── db/migration/        # Flyway migration scripts
├── application.yml      # Main configuration
├── application-dev.yml  # Development profile
└── application-prod.yml # Production profile
```

## 🔐 Security

The application implements:
- JWT-based authentication
- Role-Based Access Control (RBAC)
- Fine-grained permissions
- Password encryption (BCrypt)
- Audit logging

## 📊 Database Schema

The database follows a normalized design with modules:
- User Management (users, roles, permissions)
- Employee Management (employees, departments, contracts)
- Payroll Management (periods, components, processing)
- Settings (countries, currencies, statutory configurations)

## 🧪 Testing

Run tests:
```bash
mvn test
```

Run with coverage:
```bash
mvn test jacoco:report
```

## 🌍 Multi-Country Support

Currently supports:
- 🇺🇬 **Uganda** (Primary) - URA, NSSF, LST
- 🇰🇪 **Kenya** (Planned) - KRA, NSSF, NHIF, Housing Levy
- 🇿🇲 **Zambia** (Planned) - ZRA, NAPSA, NHIMA

## 📝 Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| DB_USERNAME | Database username | postgres |
| DB_PASSWORD | Database password | postgres |
| JWT_SECRET | JWT signing key | (auto-generated) |
| CORS_ORIGINS | Allowed CORS origins | http://localhost:3000,http://localhost:5173,https://hr.coremoja.com |

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Write/update tests
4. Submit a pull request

## 📄 License

Proprietary - All rights reserved

## 📞 Support

For issues or questions, contact the development team.

---

**Version**: 1.0.0  
**Last Updated**: 2024
