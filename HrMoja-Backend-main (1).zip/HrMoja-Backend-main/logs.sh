#!/bin/bash

# HRMoja Logs Script
# This script shows logs for the application

SERVICE=${1:-backend}

echo "Showing logs for service: $SERVICE"
echo "Press Ctrl+C to exit"
echo ""

docker-compose logs -f "$SERVICE"
